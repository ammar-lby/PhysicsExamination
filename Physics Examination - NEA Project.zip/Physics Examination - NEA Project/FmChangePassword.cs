﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.OleDb;

namespace Physics_Examination___NEA_Project
{
    public partial class FmChangePassword : Form
    {
        public FmChangePassword()
        {
            InitializeComponent();
        }



        private void btnChange_Click(object sender, EventArgs e)
        {
            bool valid = true;
            String StudCode, NPW, confirm;
            StudCode = txtStudentID.Text;
            NPW = txtNewPassword.Text;
            confirm = txtConfirmPassword.Text;
            if (StudCode != null)
            {
                OleDbConnection conn = new OleDbConnection(Program.connString);
                conn.Open();
                OleDbCommand Cmd = new OleDbCommand();
                Cmd.Connection = conn;
                Cmd.CommandText = "SELECT * FROM StudentAccount WHERE StudentCode ='" + StudCode + "'";
                OleDbDataReader reader = Cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    reader.Close();
                    {
                        if (NPW != null)
                        {
                            if (confirm != null)
                            {
                                if (confirm == NPW)

                                    Cmd.CommandText = "UPDATE StudentAccount SET SPWord = '" + confirm + "' WHERE StudentCode ='" + StudCode + "'";
                                Cmd.ExecuteNonQuery();
                                MessageBox.Show("Password has been changed");
                            }
                            else
                            {

                                MessageBox.Show("Password does not match please re-enter.");
                                

                            }
                        }
                        else
                        {

                            MessageBox.Show("New Password is empty");
                       
                        }
                    }
                }
                else
                {
                    Console.WriteLine("Confirm Password is empty");
                   
                }
            }
            else
            {
                MessageBox.Show("Student Code is empty");
              
            }
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            this.Close();
            this.Hide();
            FmTeacher fmteacher = new FmTeacher();
            fmteacher.ShowDialog();

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            txtConfirmPassword.Text = string.Empty;
            txtNewPassword.Text = string.Empty;
          
        }
    }
}









