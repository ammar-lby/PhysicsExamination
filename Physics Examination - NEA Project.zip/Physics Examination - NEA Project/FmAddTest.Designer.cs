﻿namespace Physics_Examination___NEA_Project
{
    partial class FmAddTest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbxAddTest = new System.Windows.Forms.GroupBox();
            this.btnCreate = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.txtTestCode = new System.Windows.Forms.TextBox();
            this.txtExamName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.gbxAddQuestion = new System.Windows.Forms.GroupBox();
            this.lblQuestionNum = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnAddQuestion = new System.Windows.Forms.Button();
            this.txtQuestion = new System.Windows.Forms.RichTextBox();
            this.btnFinish = new System.Windows.Forms.Button();
            this.txtCorrect = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtD = new System.Windows.Forms.TextBox();
            this.txtC = new System.Windows.Forms.TextBox();
            this.txtB = new System.Windows.Forms.TextBox();
            this.txtA = new System.Windows.Forms.TextBox();
            this.B = new System.Windows.Forms.Label();
            this.C = new System.Windows.Forms.Label();
            this.D = new System.Windows.Forms.Label();
            this.A = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.gbxAddTest.SuspendLayout();
            this.gbxAddQuestion.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbxAddTest
            // 
            this.gbxAddTest.Controls.Add(this.btnCreate);
            this.gbxAddTest.Controls.Add(this.btnExit);
            this.gbxAddTest.Controls.Add(this.txtTestCode);
            this.gbxAddTest.Controls.Add(this.txtExamName);
            this.gbxAddTest.Controls.Add(this.label2);
            this.gbxAddTest.Controls.Add(this.label1);
            this.gbxAddTest.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbxAddTest.Location = new System.Drawing.Point(12, 21);
            this.gbxAddTest.Name = "gbxAddTest";
            this.gbxAddTest.Size = new System.Drawing.Size(305, 146);
            this.gbxAddTest.TabIndex = 0;
            this.gbxAddTest.TabStop = false;
            this.gbxAddTest.Text = "Add Test";
            // 
            // btnCreate
            // 
            this.btnCreate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCreate.Location = new System.Drawing.Point(172, 108);
            this.btnCreate.Name = "btnCreate";
            this.btnCreate.Size = new System.Drawing.Size(90, 23);
            this.btnCreate.TabIndex = 3;
            this.btnCreate.Text = "Create";
            this.btnCreate.UseVisualStyleBackColor = true;
            this.btnCreate.Click += new System.EventHandler(this.btnCreate_Click);
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(32, 108);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 2;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            // 
            // txtTestCode
            // 
            this.txtTestCode.Location = new System.Drawing.Point(131, 71);
            this.txtTestCode.Name = "txtTestCode";
            this.txtTestCode.Size = new System.Drawing.Size(84, 20);
            this.txtTestCode.TabIndex = 4;
            // 
            // txtExamName
            // 
            this.txtExamName.Location = new System.Drawing.Point(131, 37);
            this.txtExamName.Name = "txtExamName";
            this.txtExamName.Size = new System.Drawing.Size(131, 20);
            this.txtExamName.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(29, 37);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Examination name:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(29, 74);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Examination ID:";
            // 
            // gbxAddQuestion
            // 
            this.gbxAddQuestion.BackColor = System.Drawing.Color.DarkTurquoise;
            this.gbxAddQuestion.Controls.Add(this.lblQuestionNum);
            this.gbxAddQuestion.Controls.Add(this.label5);
            this.gbxAddQuestion.Controls.Add(this.btnAddQuestion);
            this.gbxAddQuestion.Controls.Add(this.txtQuestion);
            this.gbxAddQuestion.Controls.Add(this.btnFinish);
            this.gbxAddQuestion.Controls.Add(this.txtCorrect);
            this.gbxAddQuestion.Controls.Add(this.label4);
            this.gbxAddQuestion.Controls.Add(this.txtD);
            this.gbxAddQuestion.Controls.Add(this.txtC);
            this.gbxAddQuestion.Controls.Add(this.txtB);
            this.gbxAddQuestion.Controls.Add(this.txtA);
            this.gbxAddQuestion.Controls.Add(this.B);
            this.gbxAddQuestion.Controls.Add(this.C);
            this.gbxAddQuestion.Controls.Add(this.D);
            this.gbxAddQuestion.Controls.Add(this.A);
            this.gbxAddQuestion.Location = new System.Drawing.Point(340, 12);
            this.gbxAddQuestion.Name = "gbxAddQuestion";
            this.gbxAddQuestion.Size = new System.Drawing.Size(448, 371);
            this.gbxAddQuestion.TabIndex = 1;
            this.gbxAddQuestion.TabStop = false;
            this.gbxAddQuestion.Text = "Add Question to Examination:";
            // 
            // lblQuestionNum
            // 
            this.lblQuestionNum.AutoSize = true;
            this.lblQuestionNum.Location = new System.Drawing.Point(26, 80);
            this.lblQuestionNum.Name = "lblQuestionNum";
            this.lblQuestionNum.Size = new System.Drawing.Size(69, 13);
            this.lblQuestionNum.TabIndex = 21;
            this.lblQuestionNum.Text = "numQuestion";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(26, 53);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 13);
            this.label5.TabIndex = 18;
            this.label5.Text = "Question:";
            // 
            // btnAddQuestion
            // 
            this.btnAddQuestion.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddQuestion.Location = new System.Drawing.Point(378, 316);
            this.btnAddQuestion.Name = "btnAddQuestion";
            this.btnAddQuestion.Size = new System.Drawing.Size(64, 49);
            this.btnAddQuestion.TabIndex = 17;
            this.btnAddQuestion.Text = "Add Question";
            this.btnAddQuestion.UseVisualStyleBackColor = true;
            this.btnAddQuestion.Click += new System.EventHandler(this.btnAddQuestion_Click);
            // 
            // txtQuestion
            // 
            this.txtQuestion.Location = new System.Drawing.Point(105, 43);
            this.txtQuestion.Name = "txtQuestion";
            this.txtQuestion.Size = new System.Drawing.Size(337, 106);
            this.txtQuestion.TabIndex = 16;
            this.txtQuestion.Text = "";
            // 
            // btnFinish
            // 
            this.btnFinish.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFinish.Location = new System.Drawing.Point(272, 330);
            this.btnFinish.Name = "btnFinish";
            this.btnFinish.Size = new System.Drawing.Size(75, 23);
            this.btnFinish.TabIndex = 5;
            this.btnFinish.Text = "Finish";
            this.btnFinish.UseVisualStyleBackColor = true;
            this.btnFinish.Click += new System.EventHandler(this.btnFinish_Click);
            // 
            // txtCorrect
            // 
            this.txtCorrect.Location = new System.Drawing.Point(123, 316);
            this.txtCorrect.Name = "txtCorrect";
            this.txtCorrect.Size = new System.Drawing.Size(127, 20);
            this.txtCorrect.TabIndex = 15;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(35, 319);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(82, 13);
            this.label4.TabIndex = 14;
            this.label4.Text = "Correct Answer:";
            // 
            // txtD
            // 
            this.txtD.Location = new System.Drawing.Point(38, 279);
            this.txtD.Name = "txtD";
            this.txtD.Size = new System.Drawing.Size(349, 20);
            this.txtD.TabIndex = 13;
            // 
            // txtC
            // 
            this.txtC.Location = new System.Drawing.Point(38, 243);
            this.txtC.Name = "txtC";
            this.txtC.Size = new System.Drawing.Size(349, 20);
            this.txtC.TabIndex = 12;
            // 
            // txtB
            // 
            this.txtB.Location = new System.Drawing.Point(38, 209);
            this.txtB.Name = "txtB";
            this.txtB.Size = new System.Drawing.Size(349, 20);
            this.txtB.TabIndex = 11;
            // 
            // txtA
            // 
            this.txtA.Location = new System.Drawing.Point(38, 174);
            this.txtA.Name = "txtA";
            this.txtA.Size = new System.Drawing.Size(349, 20);
            this.txtA.TabIndex = 10;
            // 
            // B
            // 
            this.B.AutoSize = true;
            this.B.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B.Location = new System.Drawing.Point(6, 209);
            this.B.Name = "B";
            this.B.Size = new System.Drawing.Size(17, 13);
            this.B.TabIndex = 9;
            this.B.Text = "B:";
            // 
            // C
            // 
            this.C.AutoSize = true;
            this.C.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C.Location = new System.Drawing.Point(6, 243);
            this.C.Name = "C";
            this.C.Size = new System.Drawing.Size(17, 13);
            this.C.TabIndex = 8;
            this.C.Text = "C:";
            // 
            // D
            // 
            this.D.AutoSize = true;
            this.D.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.D.Location = new System.Drawing.Point(6, 279);
            this.D.Name = "D";
            this.D.Size = new System.Drawing.Size(18, 13);
            this.D.TabIndex = 7;
            this.D.Text = "D:";
            // 
            // A
            // 
            this.A.AutoSize = true;
            this.A.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A.Location = new System.Drawing.Point(6, 174);
            this.A.Name = "A";
            this.A.Size = new System.Drawing.Size(17, 13);
            this.A.TabIndex = 3;
            this.A.Text = "A:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(0, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(35, 13);
            this.label6.TabIndex = 2;
            this.label6.Text = "label6";
            // 
            // FmAddTest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkTurquoise;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.gbxAddTest);
            this.Controls.Add(this.gbxAddQuestion);
            this.Name = "FmAddTest";
            this.Text = "FmAddTest";
            this.gbxAddTest.ResumeLayout(false);
            this.gbxAddTest.PerformLayout();
            this.gbxAddQuestion.ResumeLayout(false);
            this.gbxAddQuestion.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gbxAddTest;
        private System.Windows.Forms.GroupBox gbxAddQuestion;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnCreate;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.TextBox txtTestCode;
        private System.Windows.Forms.TextBox txtExamName;
        private System.Windows.Forms.TextBox txtCorrect;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtD;
        private System.Windows.Forms.TextBox txtC;
        private System.Windows.Forms.TextBox txtB;
        private System.Windows.Forms.TextBox txtA;
        private System.Windows.Forms.Label B;
        private System.Windows.Forms.Label C;
        private System.Windows.Forms.Label D;
        private System.Windows.Forms.Label A;
        private System.Windows.Forms.RichTextBox txtQuestion;
        private System.Windows.Forms.Button btnFinish;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnAddQuestion;
        private System.Windows.Forms.Label lblQuestionNum;
        private System.Windows.Forms.Label label6;
    }
}