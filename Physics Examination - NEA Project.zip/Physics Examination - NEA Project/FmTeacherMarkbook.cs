﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.OleDb;
using System.CodeDom.Compiler;

namespace Physics_Examination___NEA_Project
{
    public partial class FmTeacherMarkbook : Form
    {
        public FmTeacherMarkbook()
        {
            InitializeComponent();
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            if (rbtnListTest.Checked)
            {
                OleDbConnection conn = new OleDbConnection(Program.connString);
             
                OleDbCommand Cmd = new OleDbCommand();

                Cmd.CommandText = "SELECT * FROM Results WHERE TestResult = '" + cbxSelectExam.SelectedValue + "'";
                Cmd.Connection = conn;

                OleDbDataAdapter dataAdapter = new OleDbDataAdapter(Cmd);
                DataSet dataset = new DataSet();
                dataAdapter.Fill(dataset);

                datagridResults.DataSource = dataset.Tables[0];
            }
            else if (rbtnListAverage.Checked)
            {
                OleDbConnection conn = new OleDbConnection(Program.connString);
                conn.Open();
                OleDbCommand Cmd = new OleDbCommand();
                Cmd.Connection = conn;
                Cmd.CommandText = "SELECT TestResult FROM Results WHERE TestCode ='" + cbxSelectExam.SelectedValue + "'";
                OleDbDataReader reader = Cmd.ExecuteReader();
                int total = 0;
                int count = 0;
                while (reader.Read())
                {
                    string temp = reader["TestResult"].ToString();
                    int Itemp = Convert.ToInt32(temp);
                    total = total + Itemp;
                    count++;
                }
                float avg = total / count;
                rbtnListAverage.Text = "Average Marks: " + avg.ToString();
                reader.Close();
                conn.Close();
            }
            else if (rbtnListSpecific.Checked)
            {

                if (txtStudentID.Text != "")
                    
                {
                    OleDbConnection conn = new OleDbConnection(Program.connString);
                    conn.Open();
                    OleDbCommand Cmd = new OleDbCommand();
                    Cmd.Connection = conn;
                    Cmd.CommandText = "SELECT * StudentCode FROM Student Account WHERE StudentCode ='" + txtStudentID.Text + "'";
                    Cmd.ExecuteNonQuery();
                    Cmd.CommandText =  "SELECT* FROM Results WHERE TestCode = '" + cbxSelectExam.SelectedValue + "'";
                    Cmd.ExecuteNonQuery();

               
                    conn.Close();

                }
                else
                {
                    MessageBox.Show("Student ID has not been entered.");
                }
            }
            else
            {
                MessageBox.Show("No option has been selected");
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
            this.Hide();
            FmTeacher fmteacher = new FmTeacher();
            fmteacher.ShowDialog();

        }


        private void datagridResults_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            OleDbConnection conn = new OleDbConnection(Program.connString);
            conn.Open();
            OleDbCommand Cmd = new OleDbCommand();
            Cmd.Connection = conn;
            Cmd.CommandText = "SELECT * FROM Test";
            OleDbDataAdapter dataAdapter = new OleDbDataAdapter(Cmd);
            DataSet dataset = new DataSet();
            dataAdapter.Fill(dataset);
            conn.Close();
            cbxSelectExam.DataSource = dataset.Tables[0];
            cbxSelectExam.ValueMember = "TestCode";
            cbxSelectExam.DisplayMember = "TestName";
            conn.Close();
        }
    }
}



