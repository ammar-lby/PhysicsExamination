﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Physics_Examination___NEA_Project
{
    public partial class FmScientificCalc : Form
    {
        public FmScientificCalc()
        {
            InitializeComponent();
        }

        private float _1stnumber, _2ndnumber;
        private string _value = "0";
        private string _operation = null;

        #region assign_number

        private void number0_Click(object sender, EventArgs e)
        {
            if (_value == "0") _value = "0";
            else _value += "0";
            Display();
        }

        private void number1_Click(object sender, EventArgs e)
        {
            if (_value == "0") _value = "1";
            else _value += "1";
            Display();
        }

        private void number2_Click(object sender, EventArgs e)
        {
            if (_value == "0") _value = "2";
            else _value += "2";
            Display();
        }

        private void number3_Click(object sender, EventArgs e)
        {
            if (_value == "0") _value = "3";
            else _value += "3";
            Display();
        }

        private void number4_Click(object sender, EventArgs e)
        {
            if (_value == "0") _value = "4";
            else _value += "4";
            Display();
        }

        private void number5_Click(object sender, EventArgs e)
        {
            if (_value == "0") _value = "5";
            else _value += "5";
            Display();
        }

        private void number6_Click(object sender, EventArgs e)
        {
            if (_value == "0") _value = "6";
            else _value += "6";
            Display();
        }

        private void number7_Click(object sender, EventArgs e)
        {
            if (_value == "0") _value = "7";
            else _value += "7";
            Display();
        }

        private void number8_Click(object sender, EventArgs e)
        {
            if (_value == "0") _value = "8";
            else _value += "8";
            Display();
        }
        private void number9_Click(object sender, EventArgs e)
        {
            if (_value == "0") _value = "9";
            else _value += "9";
            Display();

        }
        #endregion

        private void plus_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(_operation))
            {
                _operation = "+";
            }
            else
            {
                Calculate();
                _1stnumber = float.Parse(_value);
                Display();
                _operation = "+";
            }
            _1stnumber = float.Parse(_value);
            _value = "0";
        }

        private void Calculate()
        {
            _2ndnumber = float.Parse(_value);
            switch (_operation)
            {
                case "+":
                    _value = (_1stnumber + _2ndnumber).ToString();
                    break;
                case "-":
                    _value = (_1stnumber - _2ndnumber).ToString();
                    break;
                case "/":
                    _value = (_1stnumber / _2ndnumber).ToString();
                    break;
                case "*":
                    _value = (_1stnumber * _2ndnumber).ToString();
                    break;
            }
            Display();
            _operation = null;

        }
        private void Display()
        {
            lblDisplay.Text = _value;
        }

        private void Clear_Click(object sender, EventArgs e)
        {
            _value = "0";
            Display();
        }

        private void equals_Click(object sender, EventArgs e)
        {
            Calculate();
        }

        private void decimalDot_Click(object sender, EventArgs e)
        {
            if (!_value.Contains("."))
            {

                _value += ".";
                Display();
            }
        }

        private void subtract_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(_operation))
            {
                _operation = "-";
            }
            else
            {
                Calculate();
                _1stnumber = float.Parse(_value);
                Display();
                _operation = "-";
            }
            _1stnumber = float.Parse(_value);
            _value = "0";
        }

        private void multiply_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(_operation))
            {
                _operation = "*";
            }
            else
            {
                Calculate();
                _1stnumber = float.Parse(_value);
                Display();
                _operation = "*";
            }
            _1stnumber = float.Parse(_value);
            _value = "0";
        }

        private void div_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(_operation))
            {
                _operation = "/";
            }
            else
            {
                Calculate();
                _1stnumber = float.Parse(_value);
                Display();
                _operation = "/";
            }
            _1stnumber = float.Parse(_value);
            _value = "0";
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            this.Close();
            this.Hide();
            FmCompleteExam fmcompleteexam = new FmCompleteExam();
            fmcompleteexam.ShowDialog();
        }

        private void btnSin_Click(object sender, EventArgs e)
        {
            double sin = Convert.ToDouble(lblDisplay.Text);
            sin = Math.Sin(sin);
            lblDisplay.Text = (Convert.ToString(sin));
        }

        private void btnCubed_Click(object sender, EventArgs e)
        {
            double x, q, p, m;

            q = Convert.ToDouble(lblDisplay.Text);
            m = Convert.ToDouble(lblDisplay.Text);
            p = Convert.ToDouble(lblDisplay.Text);

            x = (q * p * m);
            lblDisplay.Text = Convert.ToString(x);

        }

        private void Sqrt_Click(object sender, EventArgs e)
        {
            double sq = Convert.ToDouble(lblDisplay.Text);
            sq = Math.Sqrt(sq);
            lblDisplay.Text = (Convert.ToString(sq));
        }

        private void btnCos_Click(object sender, EventArgs e)
        {
            double cs = Convert.ToDouble(lblDisplay.Text);
            cs = Math.Cos(cs);
            lblDisplay.Text = (Convert.ToString(cs));
        }

        private void btnTan_Click(object sender, EventArgs e)
        {
            double tn = Convert.ToDouble(lblDisplay.Text);
            tn = Math.Tan(tn);
            lblDisplay.Text = (Convert.ToString(tn));
        }

        private void Pi_Click(object sender, EventArgs e)
        {
            lblDisplay.Text = "3.141592653589976323";
        }

        private void btnLog_Click(object sender, EventArgs e)
        {
            double lgg = Convert.ToDouble(lblDisplay.Text);
            lgg = Math.Log10(lgg);
            lblDisplay.Text = Convert.ToString(lgg);

        }

        private void buttonRightBracket_Click(object sender, EventArgs e)
        {
            if (!_value.Contains(")"))
            {

                _value += ")";
                Display();
            }
        }
        private void btnLeftBracket_Click(object sender, EventArgs e)
        {
            if (!_value.Contains("("))
            {

                _value += "(";
                Display();
            }
        }



        private void btnSquared_Click(object sender, EventArgs e)
        {
            double x;

            x = Convert.ToDouble(lblDisplay.Text) * Convert.ToDouble(lblDisplay.Text);
            lblDisplay.Text = Convert.ToString(x);
        }

        private void BtnFactorial_Click(object sender, EventArgs e)
        {
            int Factorial(int n)
            {
                if (n == 0)
                {
                    return 1;
                }
                else
                {
                    return n * Factorial(n - 1);
                }
            }
        }
    }
}

       


        
    


