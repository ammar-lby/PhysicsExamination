﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Data.OleDb;

namespace Physics_Examination___NEA_Project
{
    class mergeSort
    {
        static void Main(string[] args)
        {
            int[] Results = { 40, 55, 32, 76, 67, 17, 26, 68 };

            Console.WriteLine("Before sorting:");
            PrintArray(Results);

            MergeSort(Results, 0, Results.Length - 1);

            Console.WriteLine("\nAfter sorting:");
            PrintArray(Results);
        }

        static void MergeSort(int[] arr, int left, int right)
        {
            if (left < right)
            {
                int middle = (left + right) / 2;

                MergeSort(arr, left, middle);
                MergeSort(arr, middle + 1, right);

                Merge(arr, left, middle, right);
            }
            
        } 

        static void Merge(int[] arr, int left, int middle, int right)
        {
            int g, f, k;
            int n1 = middle - left + 1;
            int n2 = right - middle;

            int[] L = new int[n1];
            int[] R = new int[n2];

            for (g = 0; g < n1; g++)
            {
                L[g] = arr[left + g];
            }
            for (f = 0; f < n2; f++)
            {
                R[f] = arr[middle + 1 + f];
            }

            g = 0;
            f = 0;
            k = left;
            while (g < n1 && f < n2)
            {
                if (L[g] <= R[f])
                {
                    arr[k] = L[g];
                    g++;
                }
                else
                {
                    arr[k] = R[f];
                    f++;
                }
                k++;
            }

            while (g < n1)
            {
                arr[k] = L[g];
                g++;
                k++;
            }

            while (f < n2)
            {
                arr[k] = R[f];
                f++;
                k++;
            }
        }

        static void PrintArray(int[] arr)
        {
            for (int g = 0; g< arr.Length; g++)
            {
                Console.Write(arr[g] + " ");
            }
            Console.WriteLine();
        }
    }
}

