﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.OleDb;

namespace Physics_Examination___NEA_Project
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtLogin_Click(object sender, EventArgs e)
        {
            this.Hide();
            FmLogin FmLog = new FmLogin();
            FmLog.ShowDialog();
        }

        private void BtSignUp_Click(object sender, EventArgs e)
        {
            this.Hide();
            FmSignUp FmSign = new FmSignUp();
            FmSign.ShowDialog();
        }


        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {


                if (!File.Exists("Physics.accdb")) //checks to see if database exists
                {
                    ADOX.Catalog cat = new ADOX.Catalog();
                    cat.Create(Program.connString); //Use constant defined in Program.cs to create database
                    OleDbConnection conn = new OleDbConnection(Program.connString);

                    conn.Open(); //Database creation
                    OleDbCommand Cmd = new OleDbCommand(); //Create a database command object
                    Cmd.Connection = conn;
                    Cmd.CommandText = "CREATE TABLE Teacher(TeacherCode VARCHAR(50),TPWord VARCHAR(60), TeacherName VARCHAR(50), Surname VARCHAR(50), PRIMARY KEY(TeacherCode))"; //Create Teachers Menu
                    Cmd.ExecuteNonQuery(); //Execute (non-query) SQL command.

                    Cmd.CommandText = "CREATE TABLE StudentAccount(StudentCode VARCHAR(8),SPWord VARCHAR(60), Forename VARCHAR(30), Surname VARCHAR(80), AVGGRADE VARCHAR(2), Target VARCHAR(2), ClassCode VARCHAR(40), FOREIGN KEY (ClassCode) REFERENCES Class(ClassCode), PRIMARY KEY (StudentCode))";
                    Cmd.ExecuteNonQuery();

                
                    Cmd.CommandText = "CREATE TABLE Class(ClassCode VARCHAR(4), TeacherCode VARCHAR (8),  PRIMARY KEY(ClassCode), FOREIGN KEY (TeacherCode) REFERENCES Teacher(TeacherCode))"; //Create Classes Table
                    Cmd.ExecuteNonQuery();


                

                    Cmd.CommandText = "CREATE TABLE Test (TestCode VARCHAR (7), TestName VARCHAR (50), PRIMARY KEY(TestCode))";
                    Cmd.ExecuteNonQuery(); // Test Table



                    Cmd.CommandText = "CREATE TABLE Questions(QuestionID INTEGER, TestCode VARCHAR (5), TestQuestion VARHCAR (100), CorrectAnswer INTEGER, PRIMARY KEY(QuestionID), FOREIGN KEY(TestCode) REFERENCES TestCode(Test))";
                    Cmd.ExecuteNonQuery(); // Questions Table

                    Cmd.CommandText = "CREATE TABLE Answers(AnswerID INTEGER, QuestionID INTEGER, TestCode VARCHAR (5), AnswerText VARCHAR (100), PRIMARY KEY (AnswerID), FOREIGN KEY (QuestionID,TestCode) REFERENCES Questions(QuestionID, TestCode))";
                    Cmd.ExecuteNonQuery(); //Answers Table


                    Cmd.CommandText = "CREATE TABLE Results (StudentCode VARCHAR(8), TestCode VARCHAR(5), TestResult INTEGER, GradeAchieved VARCHAR(2), PRIMARY KEY (TestResult), FOREIGN KEY(StudentCode) REFERENCES StudentAccount(StudentCode), FOREIGN KEY(TestCode) REFERENCES Test(TestCode))";
                    Cmd.ExecuteNonQuery(); //Results Table
                    conn.Close();//Close connection to database
                }
            }

            catch(Exception c)

            {
                MessageBox.Show(c.Message);
            }


            { 
            }

        }
    }
}

