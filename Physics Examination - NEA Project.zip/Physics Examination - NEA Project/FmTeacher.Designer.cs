﻿namespace Physics_Examination___NEA_Project
{
    partial class FmTeacher
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FmTeacher));
            this.label1 = new System.Windows.Forms.Label();
            this.btnReturn = new System.Windows.Forms.Button();
            this.btnAddExamination = new System.Windows.Forms.Button();
            this.btnAddStudent = new System.Windows.Forms.Button();
            this.btnChangePassword = new System.Windows.Forms.Button();
            this.btnChangeQuestion = new System.Windows.Forms.Button();
            this.btnMarkBook = new System.Windows.Forms.Button();
            this.gbxMenuOptions = new System.Windows.Forms.GroupBox();
            this.gbxMenuOptions.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // btnReturn
            // 
            resources.ApplyResources(this.btnReturn, "btnReturn");
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.UseVisualStyleBackColor = true;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // btnAddExamination
            // 
            resources.ApplyResources(this.btnAddExamination, "btnAddExamination");
            this.btnAddExamination.Name = "btnAddExamination";
            this.btnAddExamination.UseVisualStyleBackColor = true;
            this.btnAddExamination.Click += new System.EventHandler(this.btnAddExamination_Click);
            // 
            // btnAddStudent
            // 
            resources.ApplyResources(this.btnAddStudent, "btnAddStudent");
            this.btnAddStudent.Name = "btnAddStudent";
            this.btnAddStudent.UseVisualStyleBackColor = true;
            this.btnAddStudent.Click += new System.EventHandler(this.btnAddStudent_Click);
            // 
            // btnChangePassword
            // 
            resources.ApplyResources(this.btnChangePassword, "btnChangePassword");
            this.btnChangePassword.Name = "btnChangePassword";
            this.btnChangePassword.UseVisualStyleBackColor = true;
            this.btnChangePassword.Click += new System.EventHandler(this.btnChangePassword_Click);
            // 
            // btnChangeQuestion
            // 
            resources.ApplyResources(this.btnChangeQuestion, "btnChangeQuestion");
            this.btnChangeQuestion.Name = "btnChangeQuestion";
            this.btnChangeQuestion.UseVisualStyleBackColor = true;
            this.btnChangeQuestion.Click += new System.EventHandler(this.btnChangeQuestion_Click);
            // 
            // btnMarkBook
            // 
            resources.ApplyResources(this.btnMarkBook, "btnMarkBook");
            this.btnMarkBook.Name = "btnMarkBook";
            this.btnMarkBook.UseVisualStyleBackColor = true;
            this.btnMarkBook.Click += new System.EventHandler(this.btnMarkBook_Click);
            // 
            // gbxMenuOptions
            // 
            this.gbxMenuOptions.Controls.Add(this.btnMarkBook);
            this.gbxMenuOptions.Controls.Add(this.btnChangeQuestion);
            this.gbxMenuOptions.Controls.Add(this.btnChangePassword);
            this.gbxMenuOptions.Controls.Add(this.btnAddStudent);
            this.gbxMenuOptions.Controls.Add(this.btnAddExamination);
            resources.ApplyResources(this.gbxMenuOptions, "gbxMenuOptions");
            this.gbxMenuOptions.Name = "gbxMenuOptions";
            this.gbxMenuOptions.TabStop = false;
            // 
            // FmTeacher
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.gbxMenuOptions);
            this.Controls.Add(this.label1);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.Name = "FmTeacher";
            this.Load += new System.EventHandler(this.FmTeacher_Load);
            this.gbxMenuOptions.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.Button btnAddExamination;
        private System.Windows.Forms.Button btnAddStudent;
        private System.Windows.Forms.Button btnChangePassword;
        private System.Windows.Forms.Button btnChangeQuestion;
        private System.Windows.Forms.Button btnMarkBook;
        private System.Windows.Forms.GroupBox gbxMenuOptions;
    }
}