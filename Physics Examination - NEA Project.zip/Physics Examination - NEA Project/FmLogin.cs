﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.OleDb;

namespace Physics_Examination___NEA_Project
{
    public partial class FmLogin : Form
    {
        public static string StudentCode = "";
        public static FmLogin FmLoginInstance;
        public FmLogin()
        {
            InitializeComponent();
        }

        private void BtLogin_Click(object sender, EventArgs e)
        {
            OleDbConnection conn = new OleDbConnection(Program.connString);
            conn.Open(); //Open connection to database
            OleDbCommand Cmd = new OleDbCommand(); //Create a database command object
            Cmd.Connection = conn;
            if (TbUsername.Text != "")
            {
                if (TbUsername.Text.Contains("ST")) // Teacher account
                {
                    Cmd.CommandText = "SELECT * FROM Teacher WHERE TeacherCode = '" + TbUsername.Text + "'";
                    OleDbDataReader reader = Cmd.ExecuteReader();
                    if (reader.HasRows) // Checks to see if user exists
                    {
                        reader.Read();
                        if (Encrypt.HashPassword(TbPassword.Text) == reader["TPword"].ToString()) //User sent to FmTeacher if password is correct
                        {
                            conn.Close();
                            this.Hide();
                            FmTeacher fmteacher = new FmTeacher();
                            fmteacher.ShowDialog();

                        }
                        else
                        {
                            MessageBox.Show("Incorrect Password");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Username invalid");
                    }

                }

                else
                {
                    Cmd.CommandText = "SELECT * FROM StudentAccount WHERE StudentCode ='" + TbUsername.Text + "'";
                    OleDbDataReader reader = Cmd.ExecuteReader();
                    if (reader.HasRows)
                    {
                        reader.Read();
                        if (Encrypt.HashPassword(TbPassword.Text) == reader["SPWord"].ToString())
                        {
                            conn.Close();
                            this.Hide();
                            FmStudentMenu fmstudentmenu = new FmStudentMenu();
                            fmstudentmenu.ShowDialog();

                        }
                        else
                        {
                            MessageBox.Show("Incorrect Password");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Username Invalid");

                    }
                }            
           
            }
            if ((TbPassword.Text == "" || TbPassword.Text == " "))
            {
                MessageBox.Show("Password is empty");
            }
            else if ((TbUsername.Text == "" || TbUsername.Text == " ")) //if username empty)
            {
                MessageBox.Show("Username empty");
            }
        }
               

        private void BtReturn_Click(object sender, EventArgs e)
        {
            Close();
            Form1 form1 = new Form1();
            form1.Show();
        }

        private void cBoxHidePass_CheckedChanged(object sender, EventArgs e)
        {
            if(cBoxHidePass.Checked)
            {
                TbPassword.UseSystemPasswordChar = false;
            }
            else
            {
                TbPassword.UseSystemPasswordChar = true;
            }
        }
    }
    
}
   
   












