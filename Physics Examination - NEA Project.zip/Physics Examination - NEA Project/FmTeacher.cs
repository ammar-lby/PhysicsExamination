﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.OleDb;
namespace Physics_Examination___NEA_Project
{
    public partial class FmTeacher : Form
    {
        public FmTeacher()
        {
            InitializeComponent();
        }

      

        private void btnAddStudent_Click(object sender, EventArgs e)
        {        
            FmAddStudent fmaddstudent = new FmAddStudent();
            fmaddstudent.ShowDialog();    
        }

        private void btnAddExamination_Click(object sender, EventArgs e)
        {         
            FmAddTest fmaddtest = new FmAddTest();
            fmaddtest.ShowDialog();          
        }

        private void btnMarkBook_Click(object sender, EventArgs e)
        {         
            FmTeacherMarkbook fmteachermarkbook = new FmTeacherMarkbook();
            fmteachermarkbook.ShowDialog();           
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            FmLogin fmlogin = new FmLogin();
            fmlogin.ShowDialog();
        }

        private void btnChangePassword_Click(object sender, EventArgs e)
        {
            FmChangePassword fmchangepassword = new FmChangePassword();
            fmchangepassword.ShowDialog();
        }

        private void btnChangeQuestion_Click(object sender, EventArgs e)
        {
            FmChangeQuestion fmchangequestion = new FmChangeQuestion();
            fmchangequestion.ShowDialog();
        }

        private void FmTeacher_Load(object sender, EventArgs e)
        {

        }
    }
}
