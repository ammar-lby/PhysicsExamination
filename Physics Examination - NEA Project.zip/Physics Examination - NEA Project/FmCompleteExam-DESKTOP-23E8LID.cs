﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.OleDb;

namespace Physics_Examination___NEA_Project
{
    public partial class FmCompleteExam : Form
    {
        public FmCompleteExam()
        {
            InitializeComponent();
        }

        private void Calculator_Click(object sender, EventArgs e)
        {
            FmScientificCalc fmscientificcalc = new FmScientificCalc();
            fmscientificcalc.ShowDialog();

        }

        private void gbxExam_Enter(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
            this.Hide();
            FmStudentMenu fmstudentmenu = new FmStudentMenu();
            fmstudentmenu.ShowDialog();
        }
        int QID = 1;
        int answerChosen;
        int CorrectAnswer;


        private string Grade(int score)
        {
            float result = score % QID * 100;
            if (result <= 44)
            {
                return "E";
            }
            else if (result <= 51)
            {
                return "D";
            }
            else if (result <= 58)
            {
                return "C";
            }
            else if (result <= 60)
            {
                return "B";
            }
            else if (result <= 67)
            {
                return "A";
            }
            else
            {
                return "A*";
            }
        }
        private void GetQuestion()
        {
            answerChosen = -1; //Clears answer chosen
            OleDbConnection conn = new OleDbConnection(Program.connString);
            conn.Open();
            OleDbCommand Cmd = new OleDbCommand();
            Cmd.Connection = conn;
            OleDbCommand AnsCmd = new OleDbCommand();
            AnsCmd.Connection = conn;
            Cmd.CommandText = "SELECT * FROM Questions WHERE TestCode = '" + cbxTestCode.SelectedValue + "' AND QuestionID =" + QID.ToString();
            OleDbDataReader reader = Cmd.ExecuteReader();
            if (reader.HasRows)
            {
                lbQN.Text = QID.ToString();
                tbxquestion.Text = reader["TestQuestion"].ToString();
                CorrectAnswer = Convert.ToInt16(reader["CorrectAnswer"]);
                //Read in the answers
                for (int ANSID = 1; ANSID <= 4; ANSID++)
                {
                    AnsCmd.CommandText = "SELECT * FROM Answers WHERE AnswerID = " + ANSID.ToString(); AnsCmd.CommandText += " AND QuestionID=" + QID.ToString() + " AND TestCode='" + cbxTestCode.SelectedValue + "'";
                    OleDbDataReader AnsReader = AnsCmd.ExecuteReader();
                    if (ANSID == 1)
                        rbtnA.Text = AnsReader["AnswerText"].ToString();
                    else if (ANSID == 2)
                        rbtnB.Text = AnsReader["AnswerText"].ToString();
                    else if (ANSID == 3)
                        rbtnC.Text = AnsReader["AnswerText"].ToString();
                    else
                        rbtnD.Text = AnsReader["AnswerText"].ToString();
                    AnsReader.Close();
                }
            }
            else
            {
                MessageBox.Show("Test complete. Your marks:" + score);
                string achieved = Grade(score);
                reader.Close();
                OleDbCommand cmd2 = new OleDbCommand();
                cmd2.Connection = conn;
                string DOC = DateTime.Today.ToString("yyyy-MM-dd");
                cmd2.CommandText = "INSERT INTO Results VALUES('" + cbxTestCode.SelectedValue + "','" + score + "','" + achieved + "','" + DOC + "')";
                cmd2.ExecuteNonQuery();
            }
            reader.Close();
            conn.Close();
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            if (cbxTestCode != null)
            {
                MessageBox.Show("Test loaded.");
                GetQuestion();
            }
            else
            {
                MessageBox.Show("Exam code has not been entered");
            }
        }
        int score;

        private void ClearRB()
        {
            rbtnA.Checked = false;
            rbtnB.Checked = false;
            rbtnC.Checked = false;
            rbtnD.Checked = false;
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            if (answerChosen != -1)
            {
                if (answerChosen == CorrectAnswer)
                {
                    score++;
                }
                QID++;
                ClearRB();
                GetQuestion();
            }
            else
            {
                MessageBox.Show("Answer has not been chosen");
            }

        }

        private void FmCompleteExam_Load(object sender, EventArgs e)
        {
            OleDbConnection conn = new OleDbConnection(Program.connString);
            conn.Open();
            OleDbCommand Cmd = new OleDbCommand();
            Cmd.Connection = conn;
            Cmd.CommandText = "SELECT * FROM Test";
            OleDbDataAdapter dataAdapter = new OleDbDataAdapter(Cmd);
            DataSet dataset = new DataSet();
            dataAdapter.Fill(dataset); //Fill dataset with results from query 
            conn.Close();
            cbxTestCode.DataSource = dataset.Tables[0]; //Loads data into combobox
            cbxTestCode.ValueMember = "TestCode"; //Value member set to primary key only needed if not displaying the value required.
            cbxTestCode.DisplayMember = "TestName"; //This is what the cbx displays.
            conn.Close();
        }

        private void rbtnA_CheckedChanged(object sender, EventArgs e)
        {
            if (rbtnA.Checked)
                answerChosen = 1;
        }

        private void rbtnB_CheckedChanged(object sender, EventArgs e)
        {
            if (rbtnB.Checked)
                answerChosen = 2;
        }

        private void rbtnC_CheckedChanged(object sender, EventArgs e)
        {
            if (rbtnC.Checked)
                answerChosen = 3;
        }

        private void rbtnD_CheckedChanged(object sender, EventArgs e)
        {
            if (rbtnD.Checked)
                answerChosen = 4;
        }
    }
}


