﻿
namespace Physics_Examination___NEA_Project
{
    partial class FmLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtLogin = new System.Windows.Forms.Button();
            this.BtReturn = new System.Windows.Forms.Button();
            this.GbUserLogin = new System.Windows.Forms.GroupBox();
            this.cBoxHidePass = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.TbUsername = new System.Windows.Forms.TextBox();
            this.TbPassword = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.GbUserLogin.SuspendLayout();
            this.SuspendLayout();
            // 
            // BtLogin
            // 
            this.BtLogin.Location = new System.Drawing.Point(295, 134);
            this.BtLogin.Name = "BtLogin";
            this.BtLogin.Size = new System.Drawing.Size(76, 37);
            this.BtLogin.TabIndex = 0;
            this.BtLogin.Text = "Login";
            this.BtLogin.UseVisualStyleBackColor = true;
            this.BtLogin.Click += new System.EventHandler(this.BtLogin_Click);
            // 
            // BtReturn
            // 
            this.BtReturn.Location = new System.Drawing.Point(508, 369);
            this.BtReturn.Name = "BtReturn";
            this.BtReturn.Size = new System.Drawing.Size(90, 54);
            this.BtReturn.TabIndex = 1;
            this.BtReturn.Text = "Return";
            this.BtReturn.UseVisualStyleBackColor = true;
            this.BtReturn.Click += new System.EventHandler(this.BtReturn_Click);
            // 
            // GbUserLogin
            // 
            this.GbUserLogin.Controls.Add(this.cBoxHidePass);
            this.GbUserLogin.Controls.Add(this.label2);
            this.GbUserLogin.Controls.Add(this.label1);
            this.GbUserLogin.Controls.Add(this.BtLogin);
            this.GbUserLogin.Controls.Add(this.TbUsername);
            this.GbUserLogin.Controls.Add(this.TbPassword);
            this.GbUserLogin.Location = new System.Drawing.Point(118, 76);
            this.GbUserLogin.Name = "GbUserLogin";
            this.GbUserLogin.Size = new System.Drawing.Size(396, 187);
            this.GbUserLogin.TabIndex = 2;
            this.GbUserLogin.TabStop = false;
            this.GbUserLogin.Text = "Enter details";
            // 
            // cBoxHidePass
            // 
            this.cBoxHidePass.AutoSize = true;
            this.cBoxHidePass.Location = new System.Drawing.Point(276, 89);
            this.cBoxHidePass.Name = "cBoxHidePass";
            this.cBoxHidePass.Size = new System.Drawing.Size(53, 17);
            this.cBoxHidePass.TabIndex = 4;
            this.cBoxHidePass.Text = "Show";
            this.cBoxHidePass.UseVisualStyleBackColor = true;
            this.cBoxHidePass.CheckedChanged += new System.EventHandler(this.cBoxHidePass_CheckedChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(74, 94);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Password:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(72, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Username:";
            // 
            // TbUsername
            // 
            this.TbUsername.Location = new System.Drawing.Point(136, 47);
            this.TbUsername.Name = "TbUsername";
            this.TbUsername.Size = new System.Drawing.Size(125, 20);
            this.TbUsername.TabIndex = 1;
            // 
            // TbPassword
            // 
            this.TbPassword.Location = new System.Drawing.Point(136, 87);
            this.TbPassword.Name = "TbPassword";
            this.TbPassword.Size = new System.Drawing.Size(125, 20);
            this.TbPassword.TabIndex = 0;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("MS Reference Specialty", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.label3.Location = new System.Drawing.Point(209, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(183, 40);
            this.label3.TabIndex = 3;
            this.label3.Text = "Physics ";
            // 
            // FmLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.RoyalBlue;
            this.ClientSize = new System.Drawing.Size(624, 439);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.GbUserLogin);
            this.Controls.Add(this.BtReturn);
            this.Name = "FmLogin";
            this.Text = "FmLogin";
            this.GbUserLogin.ResumeLayout(false);
            this.GbUserLogin.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtLogin;
        private System.Windows.Forms.Button BtReturn;
        private System.Windows.Forms.GroupBox GbUserLogin;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TbUsername;
        private System.Windows.Forms.TextBox TbPassword;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox cBoxHidePass;
    }
}