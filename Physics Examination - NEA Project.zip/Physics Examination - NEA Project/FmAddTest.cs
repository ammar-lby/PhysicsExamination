﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.OleDb;
using System.Windows.Forms.VisualStyles;
using System.Runtime.InteropServices;


namespace Physics_Examination___NEA_Project

{

    public partial class FmAddTest : Form

    {

        public FmAddTest()

        {

            InitializeComponent();



        }

        int QID = 1;
        bool created = false;

        private void Cleartest()

        {

            txtTestCode.Text = string.Empty;
            txtExamName.Text = string.Empty;

        }

        string TestCode;


        private void btnCreate_Click(object sender, EventArgs e)

        {
            
            bool valid = true;
            if (txtTestCode.Text.Length == 5)

            {

                OleDbConnection conn = new OleDbConnection(Program.connString);
                conn.Open(); //Open connection to database 
                OleDbCommand Cmd = new OleDbCommand(); //Create a database command object 
                Cmd.Connection = conn;
                Cmd.CommandText = "SELECT * FROM Test WHERE TestCode ='" + txtTestCode.Text + "'";
                OleDbDataReader reader = Cmd.ExecuteReader();

                if (!reader.HasRows)

                {

                    conn.Close();

                    if (txtExamName.Text != null)

                    {

                        if (valid == true)

                        {

                            conn = new OleDbConnection(Program.connString);
                            conn.Open();
                            Cmd = new OleDbCommand();
                            Cmd.Connection = conn;
                            string ExamName;
                            TestCode = txtTestCode.Text;
                            ExamName = txtExamName.Text;
                            Cmd.CommandText = "INSERT INTO Test VALUES ('" + TestCode + "','" + ExamName + "')";
                            Cmd.ExecuteNonQuery();
                            MessageBox.Show("Test added");
                            Cleartest();
                            conn.Close();
                            created = true;
                            lblQuestionNum.Text = QID.ToString();

                        }

                    }

                    else

                    {

                        valid = false;

                        MessageBox.Show("Exam name entered is invalid please re-enter");

                    }
                }




                else

                {

                    valid = false;

                    MessageBox.Show("Exam name and ID empty, please enter values");

                }

            }





        }

        private void btnFinish_Click(object sender, EventArgs e)

        {

            if (QID <= 3)

            {

                MessageBox.Show("Number of questions within the test is less than 3, add more questions");

            }

            else

            {

                this.Hide();

                this.Close();

                FmTeacher fmteacher = new FmTeacher();

                fmteacher.ShowDialog();

            }



        }

        private void ClearQuestion()

        {

            txtA.Text = string.Empty;

            txtB.Text = string.Empty;

            txtC.Text = string.Empty;

            txtD.Text = string.Empty;

        }



        private void btnAddQuestion_Click(object sender, EventArgs e)

        {
            try
            {



                bool canadd = true;

                if (txtQuestion.Text != "")

                {

                    if (txtA.Text != "")

                    {

                        if (txtB.Text != "")

                        {

                            if (txtC.Text != "")

                            {

                                if (txtD.Text != "")

                                {

                                    if (canadd == true) //add created to validate if the test is created 

                                    {

                                        OleDbConnection conn = new OleDbConnection(Program.connString);

                                        conn.Open();

                                        OleDbCommand Cmd = new OleDbCommand();

                                        Cmd.Connection = conn;

                                        string qtext = txtQuestion.Text;

                                        string answerid = txtCorrect.Text;

                                        string choice1 = txtA.Text;

                                        string choice2 = txtB.Text;

                                        string choice3 = txtC.Text;

                                        string choice4 = txtD.Text;

                                        int A = 1;

                                        int B = 2;

                                        int C = 3;

                                        int D = 4;



                            

                                       
                                        Cmd.CommandText = "INSERT INTO Questions VALUES (? ,? ,? ,?)";
                   
                                        Cmd.Parameters.Add(new OleDbParameter("QuestionID", QID));
                                        Cmd.Parameters.Add(new OleDbParameter("TestCode", TestCode));
                                        Cmd.Parameters.Add(new OleDbParameter("TestQuestion", qtext));
                                        Cmd.Parameters.Add(new OleDbParameter("CorrectAnswer", answerid));
                                        Cmd.ExecuteNonQuery();

                                       
                                       


                                        string command = "INSERT INTO ANSWERS VALUES (?, ?, ?, ?)";
                                        Cmd.Parameters.Add(new OleDbParameter("AnswerID", A));
                                        Cmd.Parameters.Add(new OleDbParameter("QuestionID", QID.ToString()));
                                        Cmd.Parameters.Add(new OleDbParameter("TestCode", TestCode.ToString()));
                                        Cmd.Parameters.Add(new OleDbParameter("AnswerText", choice1));
                                        Cmd.ExecuteNonQuery();

                                        Cmd.CommandText = command;

                                        Cmd.CommandText = "INSERT INTO ANSWERS VALUES (?, ?, ?, ?)";
                                        Cmd.Parameters.Add(new OleDbParameter("AnswerID", B));
                                        Cmd.Parameters.Add(new OleDbParameter("QuestionID", QID.ToString()));
                                        Cmd.Parameters.Add(new OleDbParameter("TestCode", TestCode.ToString()));
                                        Cmd.Parameters.Add(new OleDbParameter("AnswerText", choice2));
                                        Cmd.ExecuteNonQuery();

                                        Cmd.CommandText = "INSERT INTO ANSWERS VALUES (?, ?, ?, ?)";
                                        Cmd.Parameters.Add(new OleDbParameter("AnswerID", C));
                                        Cmd.Parameters.Add(new OleDbParameter("QuestionID", QID.ToString()));
                                        Cmd.Parameters.Add(new OleDbParameter("TestCode", TestCode.ToString()));
                                        Cmd.Parameters.Add(new OleDbParameter("AnswerText", choice3));
                                        Cmd.ExecuteNonQuery();

                                        Cmd.CommandText = "INSERT INTO ANSWERS VALUES (?, ?, ?, ?)";
                                        Cmd.Parameters.Add(new OleDbParameter("AnswerID", D));
                                        Cmd.Parameters.Add(new OleDbParameter("QuestionID", QID.ToString()));
                                        Cmd.Parameters.Add(new OleDbParameter("TestCode", TestCode.ToString()));
                                        Cmd.Parameters.Add(new OleDbParameter("AnswerText", choice4));
                                        Cmd.ExecuteNonQuery();
                                        QID++;
                                        lblQuestionNum.Text = QID.ToString();
                                        ClearQuestion();
                                        MessageBox.Show("Questions and choices have been added to test");
                                        conn.Close();

                                    }

                                }

                                else

                                {

                                    MessageBox.Show("No question has been entered");

                                    canadd = false;

                                }

                            }



                            else

                            {

                                MessageBox.Show("A is empty");

                                canadd = false;

                            }

                        }

                        else

                        {

                            MessageBox.Show("B is empty");

                            canadd = false;

                        }

                    }

                    else

                    {

                        MessageBox.Show("C is empty");

                        canadd = false;

                    }

                }

                else

                {

                    MessageBox.Show("D is empty");

                    canadd = false;

                }
            }
            catch (Exception d)
            {
                MessageBox.Show(d.Message);
            }

        }
    }
}




