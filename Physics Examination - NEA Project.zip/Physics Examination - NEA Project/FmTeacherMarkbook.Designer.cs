﻿namespace Physics_Examination___NEA_Project
{
    partial class FmTeacherMarkbook
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbxResult = new System.Windows.Forms.GroupBox();
            this.btnCancel = new System.Windows.Forms.Button();
            this.datagridResults = new System.Windows.Forms.DataGridView();
            this.txtStudentID = new System.Windows.Forms.TextBox();
            this.cbxSelectExam = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.gbxOption = new System.Windows.Forms.GroupBox();
            this.rbtnListSpecific = new System.Windows.Forms.RadioButton();
            this.btnSelect = new System.Windows.Forms.Button();
            this.rbtnListAverage = new System.Windows.Forms.RadioButton();
            this.rbtnListTest = new System.Windows.Forms.RadioButton();
            this.gbxResult.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datagridResults)).BeginInit();
            this.gbxOption.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbxResult
            // 
            this.gbxResult.Controls.Add(this.btnCancel);
            this.gbxResult.Controls.Add(this.datagridResults);
            this.gbxResult.Controls.Add(this.txtStudentID);
            this.gbxResult.Controls.Add(this.cbxSelectExam);
            this.gbxResult.Controls.Add(this.label2);
            this.gbxResult.Controls.Add(this.label1);
            this.gbxResult.Controls.Add(this.gbxOption);
            this.gbxResult.Location = new System.Drawing.Point(0, 0);
            this.gbxResult.Name = "gbxResult";
            this.gbxResult.Size = new System.Drawing.Size(567, 420);
            this.gbxResult.TabIndex = 0;
            this.gbxResult.TabStop = false;
            this.gbxResult.Text = "Student Results";
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(486, 351);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(63, 50);
            this.btnCancel.TabIndex = 6;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // datagridResults
            // 
            this.datagridResults.Location = new System.Drawing.Point(6, 193);
            this.datagridResults.Name = "datagridResults";
            this.datagridResults.Size = new System.Drawing.Size(456, 199);
            this.datagridResults.TabIndex = 5;
            this.datagridResults.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.datagridResults_CellContentClick);
            // 
            // txtStudentID
            // 
            this.txtStudentID.Location = new System.Drawing.Point(104, 66);
            this.txtStudentID.Name = "txtStudentID";
            this.txtStudentID.Size = new System.Drawing.Size(100, 20);
            this.txtStudentID.TabIndex = 4;
            // 
            // cbxSelectExam
            // 
            this.cbxSelectExam.FormattingEnabled = true;
            this.cbxSelectExam.Items.AddRange(new object[] {
            "Electricity",
            "Capacitors",
            "Quantum Physics",
            "Physics1",
            "Test"});
            this.cbxSelectExam.Location = new System.Drawing.Point(101, 111);
            this.cbxSelectExam.Name = "cbxSelectExam";
            this.cbxSelectExam.Size = new System.Drawing.Size(121, 21);
            this.cbxSelectExam.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(31, 114);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Select Exam";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(34, 69);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Student ID:";
            // 
            // gbxOption
            // 
            this.gbxOption.Controls.Add(this.rbtnListSpecific);
            this.gbxOption.Controls.Add(this.btnSelect);
            this.gbxOption.Controls.Add(this.rbtnListAverage);
            this.gbxOption.Controls.Add(this.rbtnListTest);
            this.gbxOption.Location = new System.Drawing.Point(237, 55);
            this.gbxOption.Name = "gbxOption";
            this.gbxOption.Size = new System.Drawing.Size(224, 112);
            this.gbxOption.TabIndex = 0;
            this.gbxOption.TabStop = false;
            this.gbxOption.Text = "Select Option";
            // 
            // rbtnListSpecific
            // 
            this.rbtnListSpecific.AutoSize = true;
            this.rbtnListSpecific.Location = new System.Drawing.Point(19, 40);
            this.rbtnListSpecific.Name = "rbtnListSpecific";
            this.rbtnListSpecific.Size = new System.Drawing.Size(113, 17);
            this.rbtnListSpecific.TabIndex = 8;
            this.rbtnListSpecific.TabStop = true;
            this.rbtnListSpecific.Text = "List specific results";
            this.rbtnListSpecific.UseVisualStyleBackColor = true;
            // 
            // btnSelect
            // 
            this.btnSelect.Location = new System.Drawing.Point(160, 63);
            this.btnSelect.Name = "btnSelect";
            this.btnSelect.Size = new System.Drawing.Size(58, 38);
            this.btnSelect.TabIndex = 7;
            this.btnSelect.Text = "Select";
            this.btnSelect.UseVisualStyleBackColor = true;
            this.btnSelect.Click += new System.EventHandler(this.btnSelect_Click);
            // 
            // rbtnListAverage
            // 
            this.rbtnListAverage.AutoSize = true;
            this.rbtnListAverage.Location = new System.Drawing.Point(19, 63);
            this.rbtnListAverage.Name = "rbtnListAverage";
            this.rbtnListAverage.Size = new System.Drawing.Size(118, 17);
            this.rbtnListAverage.TabIndex = 1;
            this.rbtnListAverage.TabStop = true;
            this.rbtnListAverage.Text = "Average test results";
            this.rbtnListAverage.UseVisualStyleBackColor = true;
            // 
            // rbtnListTest
            // 
            this.rbtnListTest.AutoSize = true;
            this.rbtnListTest.Location = new System.Drawing.Point(19, 84);
            this.rbtnListTest.Name = "rbtnListTest";
            this.rbtnListTest.Size = new System.Drawing.Size(89, 17);
            this.rbtnListTest.TabIndex = 0;
            this.rbtnListTest.TabStop = true;
            this.rbtnListTest.Text = "Exam Results";
            this.rbtnListTest.UseVisualStyleBackColor = true;
            // 
            // FmTeacherMarkbook
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(574, 436);
            this.Controls.Add(this.gbxResult);
            this.Name = "FmTeacherMarkbook";
            this.Text = "FmTeacherMarkbook";
            this.gbxResult.ResumeLayout(false);
            this.gbxResult.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datagridResults)).EndInit();
            this.gbxOption.ResumeLayout(false);
            this.gbxOption.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbxResult;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.DataGridView datagridResults;
        private System.Windows.Forms.TextBox txtStudentID;
        private System.Windows.Forms.ComboBox cbxSelectExam;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox gbxOption;
        private System.Windows.Forms.Button btnSelect;
        private System.Windows.Forms.RadioButton rbtnListAverage;
        private System.Windows.Forms.RadioButton rbtnListTest;
        private System.Windows.Forms.RadioButton rbtnListSpecific;
    }
}