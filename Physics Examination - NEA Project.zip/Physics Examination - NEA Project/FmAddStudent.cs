﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.OleDb;
using System.Windows.Forms.VisualStyles;
using System.Runtime.InteropServices;

namespace Physics_Examination___NEA_Project
{
    public partial class FmAddStudent : Form
    {
        public FmAddStudent()
        {
            InitializeComponent();
        }

        bool created = false;
        public class StackQueueComboBox
        {
            private Stack<string> stack = new Stack<string>();
            private Queue<string> queue = new Queue<string>();

            public StackQueueComboBox()
            {
                // Add items to stack and queue
                stack.Push("CL32");
                stack.Push("CL69");
                stack.Push("CL12");

                queue.Enqueue("CL32");
                queue.Enqueue("CL69");
                queue.Enqueue("CL12");
            }

            public void AddItemsToComboBox(ComboBox comboBox)
            {
                // Add items from stack to combo box
                while (stack.Count > 0)
                {
                    comboBox.Items.Add(stack.Pop());
                }

                // Add items from queue to combo box
                while (queue.Count > 0)
                {
                    comboBox.Items.Add(queue.Dequeue());
                }
            }
        }



        private void txtStudentID_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtForename_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtSurname_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtAverageGrade_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtCurrentGrade_TextChanged(object sender, EventArgs e)
        {

        }
        private void btnCancel_Click(object sender, EventArgs e)
        {
            TbUsername.Text = string.Empty;
            txtPassword.Text = string.Empty;
            txtForename.Text = string.Empty;
            txtSurname.Text = string.Empty;
            txtAVGGRADE.Text = string.Empty;
            txtTargetGrade.Text = string.Empty;
            cbxClass.Text = string.Empty;
        }
        string StudentCode;
        string ClassCode;
        bool valid = true;


        private void btnAssignClass_Click(object sender, EventArgs e)
        {


            if (TbUsername.Text.Length == 8)

            {
                OleDbConnection conn = new OleDbConnection(Program.connString);
                conn.Open();
                OleDbCommand Cmd = new OleDbCommand();
                Cmd.Connection = conn;
                Cmd.CommandText = "SELECT * FROM StudentAccount WHERE StudentCode ='" + TbUsername.Text + "'"; // Runs query and allows results to be read
                OleDbDataReader reader = Cmd.ExecuteReader();
                if (!reader.HasRows)
                {
                    conn.Close();

                    if (txtPassword.Text != "")
                    {
                        if (txtSurname.Text != "")
                        {
                            if (txtForename.Text != "")
                            {
                                if (txtTargetGrade.Text != "")
                                {
                                    if (txtAVGGRADE != null)
                                    {

                                        if (cbxClass.Text != "")

                                            if (valid == true)
                                            {
                                                conn = new OleDbConnection(Program.connString);
                                                conn.Open();
                                                Cmd = new OleDbCommand();
                                                Cmd.Connection = conn;

                                                string Password;
                                                string Forename;
                                                string Surname;
                                                string AverageGrade;
                                                string TargetGrade;
                                                



                                                StudentCode = TbUsername.Text;
                                                Password = (Encrypt.HashPassword(txtPassword.Text));
                                                Forename = txtForename.Text;
                                                Surname = txtSurname.Text;
                                                ClassCode = cbxClass.Text;
                                                AverageGrade = txtAVGGRADE.Text;
                                                TargetGrade = txtTargetGrade.Text;

                                                try
                                                {



                                                    Cmd.CommandText = "INSERT INTO StudentAccount VALUES(?, ?, ?, ?, ?, ?, ?)";
                                                    Cmd.Parameters.Add(new OleDbParameter("StudentCode" , StudentCode));
                                                    Cmd.Parameters.Add(new OleDbParameter("SPWord", Password));
                                                    Cmd.Parameters.Add(new OleDbParameter("Forename", Forename));
                                                    Cmd.Parameters.Add(new OleDbParameter("Surname", Surname));
                                                    Cmd.Parameters.Add(new OleDbParameter("AVGGRADE", AverageGrade));
                                                    Cmd.Parameters.Add(new OleDbParameter("TargetGrade", TargetGrade));
                                                    Cmd.Parameters.Add(new OleDbParameter("ClassCode", cbxClass.Text));   //SQL Parameters
                                                      


                                                    Cmd.ExecuteNonQuery();
                                                    MessageBox.Show("Account Saved");
                                                   
                                                    conn.Close();

                                                }
                                                catch (Exception f)
                                                {
                                                    MessageBox.Show(f.Message);
                                                }
                                            }
                                            else
                                            {
                                                valid = false;
                                                MessageBox.Show("This Student ID already exists");

                                            }
                                        else
                                        {
                                            MessageBox.Show("Inadequate details, please re-enter");
                                        }
                                    }
                                    else
                                    {
                                        valid = false;
                                        MessageBox.Show("Student forename is empty please re-enter.");

                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            
                this.Close();
                this.Hide();
                FmTeacher fmteacher = new FmTeacher();
                fmteacher.ShowDialog();
            }
    }
}




















