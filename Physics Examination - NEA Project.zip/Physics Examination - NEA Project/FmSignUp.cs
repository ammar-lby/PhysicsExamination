﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.OleDb;
using System.Text.RegularExpressions;

namespace Physics_Examination___NEA_Project
{
    public partial class FmSignUp : Form
    {
        public FmSignUp()
        {
            InitializeComponent();
        }

        private void BtReturn_Click(object sender, EventArgs e)
        {
            Close();
            Form1 form1 = new Form1();
            form1.Show();
        }

        private void BtRegister_Click(object sender, EventArgs e)
        {
            try // exception handling
            {
                var Username = TbUsername.Text;
                var Password = TbPassword.Text;
                var Forename = TbUsername.Text;
                var Surname = TbSurname.Text;
                var hasUpperChar = new Regex(@"[A-Z]+");
                var hasLowerChar = new Regex(@"[A-Z]+");
                var hasNumber = new Regex(@"[0-9]+");
                var hasSymbols = new Regex((@"[!@#$^&*()_+=\[{\]};:<>|./?,-]+"));


                if (Username == "" || Username == " ") //if username empty
                {
                    MessageBox.Show("Username is empty");
                }

                else if (Forename == "" || Forename == " ") //if forename is empty
                {
                    MessageBox.Show("Forename is empty");
                }
                else if (Surname == "" || Surname == " ")
                {
                    MessageBox.Show("Surname is empty");//if surname is empty
                }

                else if (Password == "" || Password == " ")
                {
                    MessageBox.Show("Password is empty");
                }

                else if (!hasNumber.IsMatch(Password))//if password does not match regex validation for numbers
                {
                    MessageBox.Show("Password should contian atleast one numeric value");
                    TbPassword.Clear();
                }

                if (!hasUpperChar.IsMatch(Password))//if password does not match regex validation for upper case characters
                {
                    MessageBox.Show("Password should contain atleast one upper case letter.");
                    TbPassword.Clear();
                }

                else if (!hasLowerChar.IsMatch(Password))
                {
                    MessageBox.Show("Password should contain atleast one lower case letter");
                    TbPassword.Clear();
                }

                else if (!hasSymbols.IsMatch(Password))
                {
                    MessageBox.Show("Password should contain atleast one special case character");
                    TbPassword.Clear();
                }
                else if (cbxClass.SelectedIndex == -1)
                {
                    MessageBox.Show("Please select a class!");
                }
               

                else //if all variables meet requirements
                {
                    try 


                    {
                        OleDbConnection conn = new OleDbConnection(Program.connString);
                        OleDbCommand cmd = new OleDbCommand(); //creates a database command object
                        OleDbDataAdapter da = new OleDbDataAdapter();
                        conn.Open();

                        if (TbUsername.Text.Contains("SY")) // Student Account
                        {

                            string register = "INSERT INTO StudentAccount (StudentCode, SPWord, Forename, Surname, ClassCode) VALUES ('" + TbUsername.Text + "','" + Encrypt.HashPassword(TbPassword.Text) + "','" + TbForename.Text + "','" + TbSurname.Text + "','" + cbxClass.Text + "')";
                            cmd = new OleDbCommand(register, conn);
                            cmd.ExecuteNonQuery();
                            conn.Close();

                            MessageBox.Show("Details saved, you can now login!");
                            TbForename.Clear();
                            TbSurname.Clear();
                            TbPassword.Clear();
                            TbUsername.Clear();
                            ResetSelection();
                        }
                   
                    else //Teacher Account
                        {
                            string register = "INSERT INTO Teacher (TeacherCode, TPWord, TeacherName, Surname) VALUES ('" + TbUsername.Text + "','" + Encrypt.HashPassword(TbPassword.Text) + "','" + TbForename.Text + "','" + TbSurname.Text + "')";
                            cmd = new OleDbCommand(register, conn);
                            cmd.ExecuteNonQuery();
                            cmd.CommandText = "INSERT INTO Class (ClassCode, TeacherCode) VALUES ('" + cbxClass.Text + "','" + TbUsername.Text + "')";
                            cmd.ExecuteNonQuery();
                            conn.Close();
                            MessageBox.Show("Details saved, you can now login as a teacher!");
                    
                        }

                    }

                    catch (Exception c) // if an exception is caught in the SQL query
                    {
                        MessageBox.Show(c.Message);
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Invalid");
            }
        }
        private void ResetSelection()
        {
            cbxClass.SelectedIndex = -1;
        }

   

        private void cbxClass_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            OleDbConnection conn2 = new OleDbConnection(Program.connString);
            conn2.Open();
            OleDbCommand cmd2 = new OleDbCommand();
            cmd2.Connection = conn2;
            cmd2.CommandText = "SELECT ClassCode FROM Class";
            OleDbDataAdapter dataAdapter = new OleDbDataAdapter(cmd2);
            DataSet dataSet = new DataSet(); // fill dataSet with results from query
            dataAdapter.Fill(dataSet); //loads data into combo box
            conn2.Close();
            cbxClass.DataSource = dataSet.Tables[0];
            cbxClass.ValueMember = "ClassCode";
            cbxClass.DisplayMember = "ClassCode";
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            TbForename.Clear();
            TbSurname.Clear();
            TbPassword.Clear();
            TbUsername.Clear();
            ResetSelection();
            
        }
    }
}








































