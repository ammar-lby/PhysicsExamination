﻿namespace Physics_Examination___NEA_Project
{
    partial class FmCompleteExam
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.gbxSelectExam = new System.Windows.Forms.GroupBox();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnSelect = new System.Windows.Forms.Button();
            this.cbxTestCode = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.gbxExam = new System.Windows.Forms.GroupBox();
            this.rbtnD = new System.Windows.Forms.RadioButton();
            this.rbtnC = new System.Windows.Forms.RadioButton();
            this.rbtnB = new System.Windows.Forms.RadioButton();
            this.rbtnA = new System.Windows.Forms.RadioButton();
            this.tbxquestion = new System.Windows.Forms.RichTextBox();
            this.btnNext = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.Calculator = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lbQN = new System.Windows.Forms.Label();
            this.gbxSelectExam.SuspendLayout();
            this.gbxExam.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbxSelectExam
            // 
            this.gbxSelectExam.Controls.Add(this.btnCancel);
            this.gbxSelectExam.Controls.Add(this.btnSelect);
            this.gbxSelectExam.Controls.Add(this.cbxTestCode);
            this.gbxSelectExam.Controls.Add(this.label1);
            this.gbxSelectExam.Location = new System.Drawing.Point(518, 19);
            this.gbxSelectExam.Name = "gbxSelectExam";
            this.gbxSelectExam.Size = new System.Drawing.Size(251, 143);
            this.gbxSelectExam.TabIndex = 0;
            this.gbxSelectExam.TabStop = false;
            this.gbxSelectExam.Text = "Select Exam";
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(9, 94);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(57, 33);
            this.btnCancel.TabIndex = 2;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            // 
            // btnSelect
            // 
            this.btnSelect.Location = new System.Drawing.Point(126, 69);
            this.btnSelect.Name = "btnSelect";
            this.btnSelect.Size = new System.Drawing.Size(75, 23);
            this.btnSelect.TabIndex = 3;
            this.btnSelect.Text = "Select";
            this.btnSelect.UseVisualStyleBackColor = true;
            this.btnSelect.Click += new System.EventHandler(this.btnSelect_Click);
            // 
            // cbxTestCode
            // 
            this.cbxTestCode.FormattingEnabled = true;
            this.cbxTestCode.Location = new System.Drawing.Point(80, 42);
            this.cbxTestCode.Name = "cbxTestCode";
            this.cbxTestCode.Size = new System.Drawing.Size(121, 21);
            this.cbxTestCode.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Exam Code:";
            // 
            // gbxExam
            // 
            this.gbxExam.Controls.Add(this.lbQN);
            this.gbxExam.Controls.Add(this.rbtnD);
            this.gbxExam.Controls.Add(this.rbtnC);
            this.gbxExam.Controls.Add(this.rbtnB);
            this.gbxExam.Controls.Add(this.rbtnA);
            this.gbxExam.Controls.Add(this.tbxquestion);
            this.gbxExam.Controls.Add(this.btnNext);
            this.gbxExam.Location = new System.Drawing.Point(12, 61);
            this.gbxExam.Name = "gbxExam";
            this.gbxExam.Size = new System.Drawing.Size(481, 366);
            this.gbxExam.TabIndex = 1;
            this.gbxExam.TabStop = false;
            this.gbxExam.Text = "Complete Exam";
            this.gbxExam.Enter += new System.EventHandler(this.gbxExam_Enter);
            // 
            // rbtnD
            // 
            this.rbtnD.AutoSize = true;
            this.rbtnD.Location = new System.Drawing.Point(16, 328);
            this.rbtnD.Name = "rbtnD";
            this.rbtnD.Size = new System.Drawing.Size(33, 17);
            this.rbtnD.TabIndex = 9;
            this.rbtnD.TabStop = true;
            this.rbtnD.Text = "D";
            this.rbtnD.UseVisualStyleBackColor = true;
            this.rbtnD.CheckedChanged += new System.EventHandler(this.rbtnD_CheckedChanged);
            // 
            // rbtnC
            // 
            this.rbtnC.AutoSize = true;
            this.rbtnC.Location = new System.Drawing.Point(16, 293);
            this.rbtnC.Name = "rbtnC";
            this.rbtnC.Size = new System.Drawing.Size(32, 17);
            this.rbtnC.TabIndex = 8;
            this.rbtnC.TabStop = true;
            this.rbtnC.Text = "C";
            this.rbtnC.UseVisualStyleBackColor = true;
            this.rbtnC.CheckedChanged += new System.EventHandler(this.rbtnC_CheckedChanged);
            // 
            // rbtnB
            // 
            this.rbtnB.AutoSize = true;
            this.rbtnB.Location = new System.Drawing.Point(16, 259);
            this.rbtnB.Name = "rbtnB";
            this.rbtnB.Size = new System.Drawing.Size(32, 17);
            this.rbtnB.TabIndex = 7;
            this.rbtnB.TabStop = true;
            this.rbtnB.Text = "B";
            this.rbtnB.UseVisualStyleBackColor = true;
            this.rbtnB.CheckedChanged += new System.EventHandler(this.rbtnB_CheckedChanged);
            // 
            // rbtnA
            // 
            this.rbtnA.AutoSize = true;
            this.rbtnA.Location = new System.Drawing.Point(16, 227);
            this.rbtnA.Name = "rbtnA";
            this.rbtnA.Size = new System.Drawing.Size(32, 17);
            this.rbtnA.TabIndex = 6;
            this.rbtnA.TabStop = true;
            this.rbtnA.Text = "A";
            this.rbtnA.UseVisualStyleBackColor = true;
            this.rbtnA.CheckedChanged += new System.EventHandler(this.rbtnA_CheckedChanged);
            // 
            // tbxquestion
            // 
            this.tbxquestion.Location = new System.Drawing.Point(6, 31);
            this.tbxquestion.Name = "tbxquestion";
            this.tbxquestion.Size = new System.Drawing.Size(446, 190);
            this.tbxquestion.TabIndex = 0;
            this.tbxquestion.Text = "";
            // 
            // btnNext
            // 
            this.btnNext.Location = new System.Drawing.Point(389, 319);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(75, 34);
            this.btnNext.TabIndex = 4;
            this.btnNext.Text = "Next";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Sylfaen", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(175, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(194, 39);
            this.label2.TabIndex = 5;
            this.label2.Text = "Physics Exam";
            // 
            // Calculator
            // 
            this.Calculator.Location = new System.Drawing.Point(694, 285);
            this.Calculator.Name = "Calculator";
            this.Calculator.Size = new System.Drawing.Size(75, 23);
            this.Calculator.TabIndex = 6;
            this.Calculator.Text = "Calculator";
            this.Calculator.UseVisualStyleBackColor = true;
            this.Calculator.Click += new System.EventHandler(this.Calculator_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(732, 390);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(56, 48);
            this.btnExit.TabIndex = 7;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lbQN
            // 
            this.lbQN.AutoSize = true;
            this.lbQN.Location = new System.Drawing.Point(440, 8);
            this.lbQN.Name = "lbQN";
            this.lbQN.Size = new System.Drawing.Size(35, 13);
            this.lbQN.TabIndex = 6;
            this.lbQN.Text = "label3";
            // 
            // FmCompleteExam
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.CornflowerBlue;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.Calculator);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.gbxExam);
            this.Controls.Add(this.gbxSelectExam);
            this.Name = "FmCompleteExam";
            this.Text = "FmCompleteExam";
            this.Load += new System.EventHandler(this.FmCompleteExam_Load);
            this.gbxSelectExam.ResumeLayout(false);
            this.gbxSelectExam.PerformLayout();
            this.gbxExam.ResumeLayout(false);
            this.gbxExam.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.GroupBox gbxSelectExam;
        private System.Windows.Forms.GroupBox gbxExam;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnSelect;
        private System.Windows.Forms.ComboBox cbxTestCode;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RichTextBox tbxquestion;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton rbtnD;
        private System.Windows.Forms.RadioButton rbtnC;
        private System.Windows.Forms.RadioButton rbtnB;
        private System.Windows.Forms.RadioButton rbtnA;
        private System.Windows.Forms.Button Calculator;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lbQN;
    }
}