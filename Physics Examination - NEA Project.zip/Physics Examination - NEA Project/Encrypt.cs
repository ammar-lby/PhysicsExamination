﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;

namespace Physics_Examination___NEA_Project
{
   public class Encrypt
    {


        public static string HashPassword(string password)
        {
            SHA1CryptoServiceProvider sha1 = new SHA1CryptoServiceProvider();

            byte[] Passwordbytes = Encoding.ASCII.GetBytes(password);

            byte[] Encryptedbytes = sha1.ComputeHash(Passwordbytes);

            return Convert.ToBase64String(Encryptedbytes);
        }
    }
}
