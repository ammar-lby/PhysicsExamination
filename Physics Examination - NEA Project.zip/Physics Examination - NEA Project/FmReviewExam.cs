﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.OleDb;

namespace Physics_Examination___NEA_Project
{
    public partial class FmReviewExam : Form
    {
        public FmReviewExam()
        {
            InitializeComponent();
        }

        private void FmReviewExam_Load(object sender, EventArgs e)
        {
            try
            {


                OleDbConnection conn = new OleDbConnection(Program.connString);
                OleDbCommand Cmd = new OleDbCommand();
                Cmd.CommandText = "SELECT GradeAchieved FROM Results";
                Cmd.Connection = conn;

                conn.Open();
                OleDbDataReader reader = Cmd.ExecuteReader();
                while (reader.Read())
                {
                    cbxTestCode.Items.Add(reader["GradeAchieved"]);
                }
                reader.Close();
                conn.Close();
            }
        
        


            catch (Exception a)
            {
                MessageBox.Show(a.Message);
            }


        }

        private void cbxTestCode_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {


                OleDbConnection conn = new OleDbConnection(Program.connString);
                OleDbCommand Cmd = new OleDbCommand();

                Cmd.CommandText = "SELECT * FROM Results WHERE TestCode = '" + cbxTestCode.SelectedValue + "'";
                Cmd.Connection = conn;

                OleDbDataAdapter dataAdapter = new OleDbDataAdapter(Cmd);
                DataSet dataset = new DataSet();
                dataAdapter.Fill(dataset);

                dataGridView1.DataSource = dataset.Tables[0];
            }


            catch (Exception o)
            {
                MessageBox.Show(o.Message);
            }

        }
        private void btnReturn_Click(object sender, EventArgs e)
        {
            this.Close();
            this.Hide();
            FmStudentMenu fmstudentmenu = new FmStudentMenu();
            fmstudentmenu.ShowDialog();
        }

       
    }
}
