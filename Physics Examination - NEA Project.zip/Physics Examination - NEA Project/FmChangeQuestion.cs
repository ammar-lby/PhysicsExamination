﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.OleDb;

namespace Physics_Examination___NEA_Project
{
    public partial class FmChangeQuestion : Form
    {
        public FmChangeQuestion()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            FmTeacher fmteacher = new FmTeacher();
            fmteacher.ShowDialog();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            txtnumQuestion.Text = string.Empty;
            txtA.Text = string.Empty;
            txtB.Text = string.Empty;
            txtC.Text = string.Empty;
            txtD.Text = string.Empty;
            cbxTestCode.SelectedValue = string.Empty;
            txtAnswer.Text = string.Empty;
        }
        private void btnChange_Click(object sender, EventArgs e)
        {
            try
            {

                int QID = Convert.ToInt16(txtnumQuestion.Text);
                if (txtA.Text != "" && txtB.Text != "" && txtC.Text != "" && txtD.Text != "" && txtAnswer.Text != "")
                {
                    int ans = Convert.ToInt32(txtAnswer.Text);
                    OleDbConnection conn = new OleDbConnection(Program.connString);
                    conn.Open();
                    OleDbCommand Cmd = new OleDbCommand();
                    Cmd.Connection = conn;

                    Cmd.CommandText = "UPDATE Questions SET TestQuestion = '" + txtnumQuestion.Text + "' WHERE TestCode = '" + cbxTestCode.SelectedValue + "' AND QuestionID = '" + QID + "'";
                    Cmd.ExecuteNonQuery();

                    Cmd.CommandText = "UPDATE Questions SET CorrectAnswer = '" + txtAnswer.Text + "' WHERE TestCode = '" + cbxTestCode.SelectedValue + "' AND QuestionID = '" + QID + "'";
                    Cmd.ExecuteNonQuery();


                    for (int ANSID = 1; ANSID <= 4; ANSID++)
                    {
                        if (ANSID == 1)
                        {
                            string anstxt = txtA.Text;
                            Cmd.CommandText = "UPDATE Answers SET AnswerText = '" + ANSID + "' WHERE AnswerID = '" + ANSID + "' AND TestCode = '" + cbxTestCode.SelectedValue + "'";
                            Cmd.ExecuteNonQuery();
                        }
                        else if (ANSID == 2)
                        {
                            string anstxt = txtB.Text;
                            Cmd.CommandText = "UPDATE Answers SET AnswerText = '" + ANSID + "' WHERE AnswerID = '" + ANSID + "' AND TestCode = '" + cbxTestCode.SelectedValue + "'";
                            Cmd.ExecuteNonQuery();

                        }

                        else if (ANSID == 3)
                        {
                            string anstxt = txtC.Text;
                            Cmd.CommandText = "UPDATE Answers SET AnswerText = '" + ANSID + "' WHERE AnswerID = '" + ANSID + "' AND TestCode = '" + cbxTestCode.SelectedValue + "'";
                            Cmd.ExecuteNonQuery();

                        }
                        else if (ANSID == 4)
                        {
                            string anstxt = txtD.Text;
                            Cmd.CommandText = "UPDATE Answers SET AnswerText = '" + ANSID + "' WHERE AnswerID = '" + ANSID + "' AND TestCode = '" + cbxTestCode.SelectedValue + "'";
                            Cmd.ExecuteNonQuery();
                        }
                    }
                    conn.Close();
                    Console.WriteLine("Question has been changed");
                    Hide();

                }
                else
                {
                    Console.WriteLine("Answer is empty please re-enter");
                }
            }
            catch (Exception g)
            {
                MessageBox.Show(g.Message);
            }
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            if (txtnumQuestion.Text != "")
            {
                int QID = Convert.ToInt16(txtnumQuestion.Text);
                OleDbConnection conn = new OleDbConnection(Program.connString);
                conn.Open();
                OleDbCommand Cmd = new OleDbCommand();
                Cmd.Connection = conn;
                OleDbCommand AnsCmd = new OleDbCommand();
                AnsCmd.Connection = conn;
                Cmd.CommandText = "SELECT * FROM Questions WHERE TestCode ='" + cbxTestCode.SelectedValue + "' AND QuestionID = '" + QID;
                OleDbDataReader reader = Cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    tbxqt.Text = reader["TestQuestion"].ToString();
                    for (int ANSID = 1; ANSID <= 4; ANSID++) //Reads in the answers
                    {
                        AnsCmd.CommandText = "SELECT * FROM Answers WHERE AnswersID =" + ANSID.ToString();
                        AnsCmd.CommandText += " AND QuestionID=" + QID + " AND TestCode='" + cbxTestCode.SelectedValue + "'";
                        OleDbDataReader AnsReader = AnsCmd.ExecuteReader();
                        if (ANSID == 1)
                            txtA.Text = AnsReader["AnswerText"].ToString();
                        else if (ANSID == 2)
                            txtB.Text = AnsReader["AnswerText"].ToString();
                        else if (ANSID == 3)
                            txtC.Text = AnsReader["AnswerText"].ToString();

                        else 
                            txtD.Text = AnsReader["AnswerText"].ToString();
                        AnsReader.Close();
                        conn.Close();
                    }
                }
                else
                {
                    MessageBox.Show("Question number has been entered incorrectly");
                }
            }
            else
            {
                MessageBox.Show("Question number has not been entered");
            }
       
        }

        private void FmChangeQuestion_Load(object sender, EventArgs e)
        {
            OleDbConnection conn = new OleDbConnection(Program.connString);
            conn.Open();
            OleDbCommand Cmd = new OleDbCommand();
            Cmd.Connection = conn;
            Cmd.CommandText = "SELECT * FROM Test";
            OleDbDataAdapter dataAdapter = new OleDbDataAdapter(Cmd);
            DataSet dataset = new DataSet();
            dataAdapter.Fill(dataset);//dataset filled with results from query
            conn.Close();
            cbxTestCode.DataSource = dataset.Tables[0]; //load data into cbx
            cbxTestCode.ValueMember = "TestCode";
            cbxTestCode.DisplayMember = "TestName";
            conn.Close();
        }

       
    }
}
