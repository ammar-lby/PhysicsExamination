﻿
namespace Physics_Examination___NEA_Project
{
    partial class FmScientificCalc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Button answer;
            this.lblMade = new System.Windows.Forms.Label();
            this.lblCasio = new System.Windows.Forms.Label();
            this.btnSquared = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btnPower = new System.Windows.Forms.Button();
            this.btnCubed = new System.Windows.Forms.Button();
            this.Sqrt = new System.Windows.Forms.Button();
            this.buttonRightBracket = new System.Windows.Forms.Button();
            this.btnTan = new System.Windows.Forms.Button();
            this.btnLeftBracket = new System.Windows.Forms.Button();
            this.btnSin = new System.Windows.Forms.Button();
            this.btnCos = new System.Windows.Forms.Button();
            this.number8 = new System.Windows.Forms.Button();
            this.number4 = new System.Windows.Forms.Button();
            this.number5 = new System.Windows.Forms.Button();
            this.number6 = new System.Windows.Forms.Button();
            this.number9 = new System.Windows.Forms.Button();
            this.number7 = new System.Windows.Forms.Button();
            this.number2 = new System.Windows.Forms.Button();
            this.number3 = new System.Windows.Forms.Button();
            this.number1 = new System.Windows.Forms.Button();
            this.number0 = new System.Windows.Forms.Button();
            this.decimalDot = new System.Windows.Forms.Button();
            this.Pi = new System.Windows.Forms.Button();
            this.equals = new System.Windows.Forms.Button();
            this.subtract = new System.Windows.Forms.Button();
            this.div = new System.Windows.Forms.Button();
            this.multiply = new System.Windows.Forms.Button();
            this.plus = new System.Windows.Forms.Button();
            this.Exit = new System.Windows.Forms.Button();
            this.Clear = new System.Windows.Forms.Button();
            this.lblDisplay = new System.Windows.Forms.Label();
            this.btnLog = new System.Windows.Forms.Button();
            this.BtnFactorial = new System.Windows.Forms.Button();
            answer = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // answer
            // 
            answer.Location = new System.Drawing.Point(204, 405);
            answer.Name = "answer";
            answer.Size = new System.Drawing.Size(41, 36);
            answer.TabIndex = 35;
            answer.Text = "ANS";
            answer.UseVisualStyleBackColor = true;
            // 
            // lblMade
            // 
            this.lblMade.AutoSize = true;
            this.lblMade.Location = new System.Drawing.Point(12, 14);
            this.lblMade.Name = "lblMade";
            this.lblMade.Size = new System.Drawing.Size(55, 13);
            this.lblMade.TabIndex = 0;
            this.lblMade.Text = "fx-85GT X";
            // 
            // lblCasio
            // 
            this.lblCasio.AutoSize = true;
            this.lblCasio.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCasio.Location = new System.Drawing.Point(120, 7);
            this.lblCasio.Name = "lblCasio";
            this.lblCasio.Size = new System.Drawing.Size(59, 20);
            this.lblCasio.TabIndex = 1;
            this.lblCasio.Text = "CASIO";
            // 
            // btnSquared
            // 
            this.btnSquared.Location = new System.Drawing.Point(100, 92);
            this.btnSquared.Name = "btnSquared";
            this.btnSquared.Size = new System.Drawing.Size(39, 22);
            this.btnSquared.TabIndex = 14;
            this.btnSquared.Text = " x²";
            this.btnSquared.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(45, 92);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(39, 22);
            this.button1.TabIndex = 15;
            this.button1.Text = "n/n";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // btnPower
            // 
            this.btnPower.Location = new System.Drawing.Point(206, 92);
            this.btnPower.Name = "btnPower";
            this.btnPower.Size = new System.Drawing.Size(39, 22);
            this.btnPower.TabIndex = 16;
            this.btnPower.Text = "x^n";
            this.btnPower.UseVisualStyleBackColor = true;
            // 
            // btnCubed
            // 
            this.btnCubed.Location = new System.Drawing.Point(152, 92);
            this.btnCubed.Name = "btnCubed";
            this.btnCubed.Size = new System.Drawing.Size(39, 22);
            this.btnCubed.TabIndex = 17;
            this.btnCubed.Text = " x3";
            this.btnCubed.UseVisualStyleBackColor = true;
            this.btnCubed.Click += new System.EventHandler(this.btnCubed_Click);
            // 
            // Sqrt
            // 
            this.Sqrt.Location = new System.Drawing.Point(45, 134);
            this.Sqrt.Name = "Sqrt";
            this.Sqrt.Size = new System.Drawing.Size(39, 22);
            this.Sqrt.TabIndex = 18;
            this.Sqrt.Text = "√";
            this.Sqrt.UseVisualStyleBackColor = true;
            this.Sqrt.Click += new System.EventHandler(this.Sqrt_Click);
            // 
            // buttonRightBracket
            // 
            this.buttonRightBracket.Location = new System.Drawing.Point(152, 179);
            this.buttonRightBracket.Name = "buttonRightBracket";
            this.buttonRightBracket.Size = new System.Drawing.Size(39, 22);
            this.buttonRightBracket.TabIndex = 23;
            this.buttonRightBracket.Text = ")";
            this.buttonRightBracket.UseVisualStyleBackColor = true;
            this.buttonRightBracket.Click += new System.EventHandler(this.buttonRightBracket_Click);
            // 
            // btnTan
            // 
            this.btnTan.Location = new System.Drawing.Point(201, 134);
            this.btnTan.Name = "btnTan";
            this.btnTan.Size = new System.Drawing.Size(39, 22);
            this.btnTan.TabIndex = 22;
            this.btnTan.Text = "tan";
            this.btnTan.UseVisualStyleBackColor = true;
            this.btnTan.Click += new System.EventHandler(this.btnTan_Click);
            // 
            // btnLeftBracket
            // 
            this.btnLeftBracket.Location = new System.Drawing.Point(97, 179);
            this.btnLeftBracket.Name = "btnLeftBracket";
            this.btnLeftBracket.Size = new System.Drawing.Size(39, 22);
            this.btnLeftBracket.TabIndex = 21;
            this.btnLeftBracket.Text = "(";
            this.btnLeftBracket.UseVisualStyleBackColor = true;
            this.btnLeftBracket.Click += new System.EventHandler(this.btnLeftBracket_Click);
            // 
            // btnSin
            // 
            this.btnSin.Location = new System.Drawing.Point(97, 134);
            this.btnSin.Name = "btnSin";
            this.btnSin.Size = new System.Drawing.Size(39, 22);
            this.btnSin.TabIndex = 20;
            this.btnSin.Text = "sin";
            this.btnSin.UseVisualStyleBackColor = true;
            this.btnSin.Click += new System.EventHandler(this.btnSin_Click);
            // 
            // btnCos
            // 
            this.btnCos.Location = new System.Drawing.Point(152, 134);
            this.btnCos.Name = "btnCos";
            this.btnCos.Size = new System.Drawing.Size(39, 22);
            this.btnCos.TabIndex = 19;
            this.btnCos.Text = "cos";
            this.btnCos.UseVisualStyleBackColor = true;
            this.btnCos.Click += new System.EventHandler(this.btnCos_Click);
            // 
            // number8
            // 
            this.number8.Location = new System.Drawing.Point(100, 237);
            this.number8.Name = "number8";
            this.number8.Size = new System.Drawing.Size(41, 36);
            this.number8.TabIndex = 24;
            this.number8.Text = "8";
            this.number8.UseVisualStyleBackColor = true;
            this.number8.Click += new System.EventHandler(this.number8_Click);
            // 
            // number4
            // 
            this.number4.Location = new System.Drawing.Point(45, 294);
            this.number4.Name = "number4";
            this.number4.Size = new System.Drawing.Size(41, 36);
            this.number4.TabIndex = 25;
            this.number4.Text = "4";
            this.number4.UseVisualStyleBackColor = true;
            this.number4.Click += new System.EventHandler(this.number4_Click);
            // 
            // number5
            // 
            this.number5.Location = new System.Drawing.Point(100, 294);
            this.number5.Name = "number5";
            this.number5.Size = new System.Drawing.Size(41, 36);
            this.number5.TabIndex = 26;
            this.number5.Text = "5";
            this.number5.UseVisualStyleBackColor = true;
            this.number5.Click += new System.EventHandler(this.number5_Click);
            // 
            // number6
            // 
            this.number6.Location = new System.Drawing.Point(152, 294);
            this.number6.Name = "number6";
            this.number6.Size = new System.Drawing.Size(41, 36);
            this.number6.TabIndex = 27;
            this.number6.Text = "6";
            this.number6.UseVisualStyleBackColor = true;
            this.number6.Click += new System.EventHandler(this.number6_Click);
            // 
            // number9
            // 
            this.number9.Location = new System.Drawing.Point(152, 237);
            this.number9.Name = "number9";
            this.number9.Size = new System.Drawing.Size(41, 36);
            this.number9.TabIndex = 28;
            this.number9.Text = "9";
            this.number9.UseVisualStyleBackColor = true;
            // 
            // number7
            // 
            this.number7.Location = new System.Drawing.Point(43, 237);
            this.number7.Name = "number7";
            this.number7.Size = new System.Drawing.Size(41, 36);
            this.number7.TabIndex = 29;
            this.number7.Text = "7";
            this.number7.UseVisualStyleBackColor = true;
            this.number7.Click += new System.EventHandler(this.number7_Click);
            // 
            // number2
            // 
            this.number2.Location = new System.Drawing.Point(100, 352);
            this.number2.Name = "number2";
            this.number2.Size = new System.Drawing.Size(41, 36);
            this.number2.TabIndex = 30;
            this.number2.Text = "2";
            this.number2.UseVisualStyleBackColor = true;
            this.number2.Click += new System.EventHandler(this.number2_Click);
            // 
            // number3
            // 
            this.number3.Location = new System.Drawing.Point(152, 352);
            this.number3.Name = "number3";
            this.number3.Size = new System.Drawing.Size(41, 36);
            this.number3.TabIndex = 31;
            this.number3.Text = "3";
            this.number3.UseVisualStyleBackColor = true;
            this.number3.Click += new System.EventHandler(this.number3_Click);
            // 
            // number1
            // 
            this.number1.Location = new System.Drawing.Point(45, 352);
            this.number1.Name = "number1";
            this.number1.Size = new System.Drawing.Size(41, 36);
            this.number1.TabIndex = 32;
            this.number1.Text = "1";
            this.number1.UseVisualStyleBackColor = true;
            this.number1.Click += new System.EventHandler(this.number1_Click);
            // 
            // number0
            // 
            this.number0.Location = new System.Drawing.Point(45, 405);
            this.number0.Name = "number0";
            this.number0.Size = new System.Drawing.Size(41, 36);
            this.number0.TabIndex = 33;
            this.number0.Text = "0";
            this.number0.UseVisualStyleBackColor = true;
            this.number0.Click += new System.EventHandler(this.number0_Click);
            // 
            // decimalDot
            // 
            this.decimalDot.Location = new System.Drawing.Point(100, 405);
            this.decimalDot.Name = "decimalDot";
            this.decimalDot.Size = new System.Drawing.Size(41, 36);
            this.decimalDot.TabIndex = 34;
            this.decimalDot.Text = ".";
            this.decimalDot.UseVisualStyleBackColor = true;
            this.decimalDot.Click += new System.EventHandler(this.decimalDot_Click);
            // 
            // Pi
            // 
            this.Pi.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.Pi.ForeColor = System.Drawing.Color.White;
            this.Pi.Location = new System.Drawing.Point(152, 405);
            this.Pi.Name = "Pi";
            this.Pi.Size = new System.Drawing.Size(41, 36);
            this.Pi.TabIndex = 36;
            this.Pi.Text = "Pi";
            this.Pi.UseVisualStyleBackColor = false;
            this.Pi.Click += new System.EventHandler(this.Pi_Click);
            // 
            // equals
            // 
            this.equals.BackColor = System.Drawing.Color.Fuchsia;
            this.equals.Location = new System.Drawing.Point(251, 412);
            this.equals.Name = "equals";
            this.equals.Size = new System.Drawing.Size(70, 62);
            this.equals.TabIndex = 37;
            this.equals.Text = "=";
            this.equals.UseVisualStyleBackColor = false;
            this.equals.Click += new System.EventHandler(this.equals_Click);
            // 
            // subtract
            // 
            this.subtract.Location = new System.Drawing.Point(262, 352);
            this.subtract.Name = "subtract";
            this.subtract.Size = new System.Drawing.Size(39, 36);
            this.subtract.TabIndex = 38;
            this.subtract.Text = "-";
            this.subtract.UseVisualStyleBackColor = true;
            this.subtract.Click += new System.EventHandler(this.subtract_Click);
            // 
            // div
            // 
            this.div.Location = new System.Drawing.Point(262, 294);
            this.div.Name = "div";
            this.div.Size = new System.Drawing.Size(39, 36);
            this.div.TabIndex = 39;
            this.div.Text = "÷";
            this.div.UseVisualStyleBackColor = true;
            this.div.Click += new System.EventHandler(this.div_Click);
            // 
            // multiply
            // 
            this.multiply.Location = new System.Drawing.Point(208, 294);
            this.multiply.Name = "multiply";
            this.multiply.Size = new System.Drawing.Size(43, 36);
            this.multiply.TabIndex = 40;
            this.multiply.Text = "x";
            this.multiply.UseVisualStyleBackColor = true;
            this.multiply.Click += new System.EventHandler(this.multiply_Click);
            // 
            // plus
            // 
            this.plus.Location = new System.Drawing.Point(208, 352);
            this.plus.Name = "plus";
            this.plus.Size = new System.Drawing.Size(39, 36);
            this.plus.TabIndex = 41;
            this.plus.Text = "+";
            this.plus.UseVisualStyleBackColor = true;
            this.plus.Click += new System.EventHandler(this.plus_Click);
            // 
            // Exit
            // 
            this.Exit.BackColor = System.Drawing.Color.Yellow;
            this.Exit.Location = new System.Drawing.Point(270, 237);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(51, 36);
            this.Exit.TabIndex = 42;
            this.Exit.Text = "AC";
            this.Exit.UseVisualStyleBackColor = false;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // Clear
            // 
            this.Clear.BackColor = System.Drawing.Color.Yellow;
            this.Clear.Location = new System.Drawing.Point(204, 237);
            this.Clear.Name = "Clear";
            this.Clear.Size = new System.Drawing.Size(56, 36);
            this.Clear.TabIndex = 43;
            this.Clear.Text = "DEL";
            this.Clear.UseVisualStyleBackColor = false;
            this.Clear.Click += new System.EventHandler(this.Clear_Click);
            // 
            // lblDisplay
            // 
            this.lblDisplay.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lblDisplay.Location = new System.Drawing.Point(31, 41);
            this.lblDisplay.Name = "lblDisplay";
            this.lblDisplay.Size = new System.Drawing.Size(261, 48);
            this.lblDisplay.TabIndex = 44;
            this.lblDisplay.Text = "0";
            // 
            // btnLog
            // 
            this.btnLog.Location = new System.Drawing.Point(253, 134);
            this.btnLog.Name = "btnLog";
            this.btnLog.Size = new System.Drawing.Size(39, 22);
            this.btnLog.TabIndex = 45;
            this.btnLog.Text = "log";
            this.btnLog.UseVisualStyleBackColor = true;
            this.btnLog.Click += new System.EventHandler(this.btnLog_Click);
            // 
            // BtnFactorial
            // 
            this.BtnFactorial.Location = new System.Drawing.Point(45, 447);
            this.BtnFactorial.Name = "BtnFactorial";
            this.BtnFactorial.Size = new System.Drawing.Size(41, 36);
            this.BtnFactorial.TabIndex = 46;
            this.BtnFactorial.Text = "!";
            this.BtnFactorial.UseVisualStyleBackColor = true;
            this.BtnFactorial.Click += new System.EventHandler(this.BtnFactorial_Click);
            // 
            // FmScientificCalc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(333, 486);
            this.Controls.Add(this.BtnFactorial);
            this.Controls.Add(this.btnLog);
            this.Controls.Add(this.lblDisplay);
            this.Controls.Add(this.Clear);
            this.Controls.Add(this.Exit);
            this.Controls.Add(this.plus);
            this.Controls.Add(this.multiply);
            this.Controls.Add(this.div);
            this.Controls.Add(this.subtract);
            this.Controls.Add(this.equals);
            this.Controls.Add(this.Pi);
            this.Controls.Add(answer);
            this.Controls.Add(this.decimalDot);
            this.Controls.Add(this.number0);
            this.Controls.Add(this.number1);
            this.Controls.Add(this.number3);
            this.Controls.Add(this.number2);
            this.Controls.Add(this.number7);
            this.Controls.Add(this.number9);
            this.Controls.Add(this.number6);
            this.Controls.Add(this.number5);
            this.Controls.Add(this.number4);
            this.Controls.Add(this.number8);
            this.Controls.Add(this.buttonRightBracket);
            this.Controls.Add(this.btnTan);
            this.Controls.Add(this.btnLeftBracket);
            this.Controls.Add(this.btnSin);
            this.Controls.Add(this.btnCos);
            this.Controls.Add(this.Sqrt);
            this.Controls.Add(this.btnCubed);
            this.Controls.Add(this.btnPower);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnSquared);
            this.Controls.Add(this.lblCasio);
            this.Controls.Add(this.lblMade);
            this.Name = "FmScientificCalc";
            this.Text = "π";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblMade;
        private System.Windows.Forms.Label lblCasio;
        private System.Windows.Forms.Button btnSquared;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnPower;
        private System.Windows.Forms.Button btnCubed;
        private System.Windows.Forms.Button Sqrt;
        private System.Windows.Forms.Button buttonRightBracket;
        private System.Windows.Forms.Button btnTan;
        private System.Windows.Forms.Button btnLeftBracket;
        private System.Windows.Forms.Button btnSin;
        private System.Windows.Forms.Button btnCos;
        private System.Windows.Forms.Button number8;
        private System.Windows.Forms.Button number4;
        private System.Windows.Forms.Button number5;
        private System.Windows.Forms.Button number6;
        private System.Windows.Forms.Button number9;
        private System.Windows.Forms.Button number7;
        private System.Windows.Forms.Button number2;
        private System.Windows.Forms.Button number3;
        private System.Windows.Forms.Button number1;
        private System.Windows.Forms.Button number0;
        private System.Windows.Forms.Button decimalDot;
        private System.Windows.Forms.Button Pi;
        private System.Windows.Forms.Button equals;
        private System.Windows.Forms.Button subtract;
        private System.Windows.Forms.Button div;
        private System.Windows.Forms.Button multiply;
        private System.Windows.Forms.Button plus;
        private System.Windows.Forms.Button Exit;
        private System.Windows.Forms.Button Clear;
        private System.Windows.Forms.Label lblDisplay;
        private System.Windows.Forms.Button btnLog;
        private System.Windows.Forms.Button BtnFactorial;
    }
}