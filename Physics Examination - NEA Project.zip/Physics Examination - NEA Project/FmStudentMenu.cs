﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Physics_Examination___NEA_Project
{
    public partial class FmStudentMenu : Form
    {
        public FmStudentMenu()
        {
            InitializeComponent();
            
        }

       
        private void btnComplete_Click(object sender, EventArgs e)
        {
            this.Hide();
            FmCompleteExam fmcompleteexam = new FmCompleteExam();
            fmcompleteexam.ShowDialog();
        }

        private void btnReview_Click(object sender, EventArgs e)
        {
            this.Hide();
            FmReviewExam fmreviewexam = new FmReviewExam();
            fmreviewexam.ShowDialog();
             
        }
  

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
            Form1 form1 = new Form1();
            form1.ShowDialog();
            
                
        }
    }
}
