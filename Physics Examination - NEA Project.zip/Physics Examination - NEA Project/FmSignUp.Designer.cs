﻿
namespace Physics_Examination___NEA_Project
{
    partial class FmSignUp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtRegister = new System.Windows.Forms.Button();
            this.BtReturn = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnCancel = new System.Windows.Forms.Button();
            this.TbPassword = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Forename = new System.Windows.Forms.Label();
            this.TbForename = new System.Windows.Forms.TextBox();
            this.TbSurname = new System.Windows.Forms.TextBox();
            this.TbUsername = new System.Windows.Forms.TextBox();
            this.cbxClass = new System.Windows.Forms.ComboBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // BtRegister
            // 
            this.BtRegister.Location = new System.Drawing.Point(151, 252);
            this.BtRegister.Name = "BtRegister";
            this.BtRegister.Size = new System.Drawing.Size(75, 41);
            this.BtRegister.TabIndex = 0;
            this.BtRegister.Text = "Register";
            this.BtRegister.UseVisualStyleBackColor = true;
            this.BtRegister.Click += new System.EventHandler(this.BtRegister_Click);
            // 
            // BtReturn
            // 
            this.BtReturn.Location = new System.Drawing.Point(386, 363);
            this.BtReturn.Name = "BtReturn";
            this.BtReturn.Size = new System.Drawing.Size(93, 75);
            this.BtReturn.TabIndex = 1;
            this.BtReturn.Text = "Return";
            this.BtReturn.UseVisualStyleBackColor = true;
            this.BtReturn.Click += new System.EventHandler(this.BtReturn_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cbxClass);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.btnCancel);
            this.groupBox1.Controls.Add(this.TbPassword);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.BtRegister);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.Forename);
            this.groupBox1.Controls.Add(this.TbForename);
            this.groupBox1.Controls.Add(this.TbSurname);
            this.groupBox1.Controls.Add(this.TbUsername);
            this.groupBox1.Location = new System.Drawing.Point(100, 45);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(257, 315);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Sign up";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(17, 252);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(32, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "Class";
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(127, 203);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 8;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // TbPassword
            // 
            this.TbPassword.Location = new System.Drawing.Point(91, 177);
            this.TbPassword.Name = "TbPassword";
            this.TbPassword.Size = new System.Drawing.Size(111, 20);
            this.TbPassword.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(31, 180);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Password";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(31, 139);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Username";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(36, 99);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Surname";
            // 
            // Forename
            // 
            this.Forename.AutoSize = true;
            this.Forename.Location = new System.Drawing.Point(31, 60);
            this.Forename.Name = "Forename";
            this.Forename.Size = new System.Drawing.Size(54, 13);
            this.Forename.TabIndex = 3;
            this.Forename.Text = "Forename";
            // 
            // TbForename
            // 
            this.TbForename.Location = new System.Drawing.Point(91, 57);
            this.TbForename.Name = "TbForename";
            this.TbForename.Size = new System.Drawing.Size(111, 20);
            this.TbForename.TabIndex = 2;
            // 
            // TbSurname
            // 
            this.TbSurname.Location = new System.Drawing.Point(91, 99);
            this.TbSurname.Name = "TbSurname";
            this.TbSurname.Size = new System.Drawing.Size(111, 20);
            this.TbSurname.TabIndex = 1;
            // 
            // TbUsername
            // 
            this.TbUsername.Location = new System.Drawing.Point(91, 136);
            this.TbUsername.Name = "TbUsername";
            this.TbUsername.Size = new System.Drawing.Size(111, 20);
            this.TbUsername.TabIndex = 0;
            // 
            // cbxClass
            // 
            this.cbxClass.FormattingEnabled = true;
            this.cbxClass.Items.AddRange(new object[] {
            "CL32",
            "CL69",
            "CL77",
            "CL12"});
            this.cbxClass.Location = new System.Drawing.Point(55, 249);
            this.cbxClass.Name = "cbxClass";
            this.cbxClass.Size = new System.Drawing.Size(72, 21);
            this.cbxClass.TabIndex = 11;
            // 
            // FmSignUp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(540, 450);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.BtReturn);
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Name = "FmSignUp";
            this.Text = "FmSignUp";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BtRegister;
        private System.Windows.Forms.Button BtReturn;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label Forename;
        private System.Windows.Forms.TextBox TbForename;
        private System.Windows.Forms.TextBox TbSurname;
        private System.Windows.Forms.TextBox TbUsername;
        private System.Windows.Forms.TextBox TbPassword;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cbxClass;
    }
}