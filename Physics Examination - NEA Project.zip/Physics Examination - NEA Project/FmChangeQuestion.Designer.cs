﻿namespace Physics_Examination___NEA_Project
{
    partial class FmChangeQuestion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbxChangeQuestion = new System.Windows.Forms.GroupBox();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnChange = new System.Windows.Forms.Button();
            this.txtAnswer = new System.Windows.Forms.TextBox();
            this.txtB = new System.Windows.Forms.TextBox();
            this.txtC = new System.Windows.Forms.TextBox();
            this.txtD = new System.Windows.Forms.TextBox();
            this.txtA = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tbxqt = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnSelect = new System.Windows.Forms.Button();
            this.txtnumQuestion = new System.Windows.Forms.TextBox();
            this.cbxTestCode = new System.Windows.Forms.ComboBox();
            this.btnExit = new System.Windows.Forms.Button();
            this.gbxChangeQuestion.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbxChangeQuestion
            // 
            this.gbxChangeQuestion.Controls.Add(this.btnCancel);
            this.gbxChangeQuestion.Controls.Add(this.btnChange);
            this.gbxChangeQuestion.Controls.Add(this.txtAnswer);
            this.gbxChangeQuestion.Controls.Add(this.txtB);
            this.gbxChangeQuestion.Controls.Add(this.txtC);
            this.gbxChangeQuestion.Controls.Add(this.txtD);
            this.gbxChangeQuestion.Controls.Add(this.txtA);
            this.gbxChangeQuestion.Controls.Add(this.label8);
            this.gbxChangeQuestion.Controls.Add(this.label7);
            this.gbxChangeQuestion.Controls.Add(this.label6);
            this.gbxChangeQuestion.Controls.Add(this.label5);
            this.gbxChangeQuestion.Controls.Add(this.label4);
            this.gbxChangeQuestion.Controls.Add(this.label3);
            this.gbxChangeQuestion.Controls.Add(this.tbxqt);
            this.gbxChangeQuestion.Controls.Add(this.label2);
            this.gbxChangeQuestion.Controls.Add(this.label1);
            this.gbxChangeQuestion.Controls.Add(this.btnSelect);
            this.gbxChangeQuestion.Controls.Add(this.txtnumQuestion);
            this.gbxChangeQuestion.Controls.Add(this.cbxTestCode);
            this.gbxChangeQuestion.Location = new System.Drawing.Point(30, 12);
            this.gbxChangeQuestion.Name = "gbxChangeQuestion";
            this.gbxChangeQuestion.Size = new System.Drawing.Size(483, 417);
            this.gbxChangeQuestion.TabIndex = 0;
            this.gbxChangeQuestion.TabStop = false;
            this.gbxChangeQuestion.Text = "Change Question";
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(15, 380);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 18;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnChange
            // 
            this.btnChange.Location = new System.Drawing.Point(367, 380);
            this.btnChange.Name = "btnChange";
            this.btnChange.Size = new System.Drawing.Size(75, 23);
            this.btnChange.TabIndex = 16;
            this.btnChange.Text = "Change";
            this.btnChange.UseVisualStyleBackColor = true;
            this.btnChange.Click += new System.EventHandler(this.btnChange_Click);
            // 
            // txtAnswer
            // 
            this.txtAnswer.Location = new System.Drawing.Point(198, 377);
            this.txtAnswer.Name = "txtAnswer";
            this.txtAnswer.Size = new System.Drawing.Size(100, 20);
            this.txtAnswer.TabIndex = 15;
            // 
            // txtB
            // 
            this.txtB.Location = new System.Drawing.Point(131, 280);
            this.txtB.Name = "txtB";
            this.txtB.Size = new System.Drawing.Size(266, 20);
            this.txtB.TabIndex = 14;
            // 
            // txtC
            // 
            this.txtC.Location = new System.Drawing.Point(131, 313);
            this.txtC.Name = "txtC";
            this.txtC.Size = new System.Drawing.Size(266, 20);
            this.txtC.TabIndex = 13;
            // 
            // txtD
            // 
            this.txtD.Location = new System.Drawing.Point(131, 344);
            this.txtD.Name = "txtD";
            this.txtD.Size = new System.Drawing.Size(266, 20);
            this.txtD.TabIndex = 12;
            // 
            // txtA
            // 
            this.txtA.Location = new System.Drawing.Point(131, 250);
            this.txtA.Name = "txtA";
            this.txtA.Size = new System.Drawing.Size(266, 20);
            this.txtA.TabIndex = 11;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(73, 313);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(14, 13);
            this.label8.TabIndex = 10;
            this.label8.Text = "C";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(73, 280);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(14, 13);
            this.label7.TabIndex = 9;
            this.label7.Text = "B";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(73, 347);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(15, 13);
            this.label6.TabIndex = 8;
            this.label6.Text = "D";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(73, 250);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(14, 13);
            this.label5.TabIndex = 7;
            this.label5.Text = "A";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(147, 380);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Answer:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(36, 108);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Question Text:";
            // 
            // tbxqt
            // 
            this.tbxqt.Location = new System.Drawing.Point(39, 124);
            this.tbxqt.Multiline = true;
            this.tbxqt.Name = "tbxqt";
            this.tbxqt.Size = new System.Drawing.Size(330, 112);
            this.tbxqt.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(102, 50);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Question number:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(133, 79);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Test Code:";
            // 
            // btnSelect
            // 
            this.btnSelect.Location = new System.Drawing.Point(340, 79);
            this.btnSelect.Name = "btnSelect";
            this.btnSelect.Size = new System.Drawing.Size(84, 23);
            this.btnSelect.TabIndex = 2;
            this.btnSelect.Text = "Select";
            this.btnSelect.UseVisualStyleBackColor = true;
            this.btnSelect.Click += new System.EventHandler(this.btnSelect_Click);
            // 
            // txtnumQuestion
            // 
            this.txtnumQuestion.Location = new System.Drawing.Point(198, 50);
            this.txtnumQuestion.Name = "txtnumQuestion";
            this.txtnumQuestion.Size = new System.Drawing.Size(100, 20);
            this.txtnumQuestion.TabIndex = 1;
            // 
            // cbxTestCode
            // 
            this.cbxTestCode.FormattingEnabled = true;
            this.cbxTestCode.Location = new System.Drawing.Point(198, 76);
            this.cbxTestCode.Name = "cbxTestCode";
            this.cbxTestCode.Size = new System.Drawing.Size(121, 21);
            this.cbxTestCode.TabIndex = 0;
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(521, 435);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(51, 37);
            this.btnExit.TabIndex = 19;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.button1_Click);
            // 
            // FmChangeQuestion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(584, 484);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.gbxChangeQuestion);
            this.Name = "FmChangeQuestion";
            this.Text = "FmChangeQuestion";
            this.Load += new System.EventHandler(this.FmChangeQuestion_Load);
            this.gbxChangeQuestion.ResumeLayout(false);
            this.gbxChangeQuestion.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbxChangeQuestion;
        private System.Windows.Forms.Button btnSelect;
        private System.Windows.Forms.TextBox txtnumQuestion;
        private System.Windows.Forms.ComboBox cbxTestCode;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtB;
        private System.Windows.Forms.TextBox txtC;
        private System.Windows.Forms.TextBox txtD;
        private System.Windows.Forms.TextBox txtA;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbxqt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnChange;
        private System.Windows.Forms.TextBox txtAnswer;
        private System.Windows.Forms.Button btnExit;
    }
}