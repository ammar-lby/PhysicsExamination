﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.OleDb;

namespace Physics_Examination___NEA_Project
{
    public partial class FmChangePassword : Form
    {
        public FmChangePassword()
        {
            InitializeComponent();
        }


    
        private void btnChange_Click(object sender, EventArgs e)
        {
            String StudCode, NPW, confirm;
            StudCode = txtStudentID.Text;
            NPW = txtNewPassword.Text;
            confirm = txtConfirmPassword.Text;
            if (StudCode != null)
            {
                OleDbConnection conn = new OleDbConnection(Program.connString);
                conn.Open();
                OleDbCommand Cmd = new OleDbCommand();
                Cmd.Connection = conn;
                Cmd.CommandText = "SELECT * FROM StudentAccount WHERE StudentCode ='" + StudCode + "'";
                OleDbDataReader reader = Cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    reader.Close();
                    {
                        if (NPW != null)
                        {
                            bool valid;
                            if (confirm != null)
                            {
                                if (confirm == NPW)
                                {
                                    Cmd.CommandText = " UPDATE StudentAccount ";
                                    Cmd.CommandText += "SET SPWord = " + confirm + "'";
                                    Cmd.CommandText += " WHERE StudentCode = '" + StudCode + "'";
                                    Cmd.ExecuteNonQuery();
                                    conn.Close();
                                    Console.WriteLine("Password has been changed");
                                    Console.ReadLine();
                                }
                                else
                                {
                                    valid = false;
                                    MessageBox.Show("The password does not match please re-enter");

                                }
                            }
                            else
                            {
                                valid = false;
                                MessageBox.Show("Student Code is inncorrect");

                            }
                        }
                    }
                }
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
            this.Hide();
            FmTeacher fmteacher = new FmTeacher();
            fmteacher.ShowDialog();
        }
    }
}




